# AUR Scanner (Bash)

> **Verify first, install later** — Security checker for AUR packages (and GitHub wrappers) with automatic installation via `yay` only if everything passes.

[![Bash](https://img.shields.io/badge/Bash-4EAA25?logo=gnu-bash&logoColor=white)](https://www.gnu.org/software/bash/)
[![Arch Linux](https://img.shields.io/badge/Arch_Linux-1793D1?logo=archlinux&logoColor=white)](https://archlinux.org/)
[![AUR](https://img.shields.io/badge/AUR-1793D1?logo=archlinux&logoColor=white)](https://aur.archlinux.org/)
[![makepkg --verifysource](https://img.shields.io/badge/makepkg--verifysource-enabled-blue)](https://wiki.archlinux.org/title/Makepkg)
[![PGP](https://img.shields.io/badge/PGP-verification-informational?logo=gnupg&logoColor=white)](https://gnupg.org/)
[![sha256](https://img.shields.io/badge/checksums-sha256-success)](https://en.wikipedia.org/wiki/SHA-2)
[![yay](https://img.shields.io/badge/helper-yay-0A0A0A)](https://github.com/Jguer/yay)
[![Ko-fi](https://img.shields.io/badge/Ko--fi-Buy%20me%20a%20coffee-FF5E5B?logo=kofi&logoColor=white)](https://ko-fi.com/luigid5555)

---

🌐 Lea esto en [Español](docs/es/README.es.md)

---

## 📚 Documentation

- Docs index: [Index](docs/INDEX.md)
- Developer docs: [English](https://github.com/LuigiD5555/aur_scanner/blob/development/docs/developer/README.dev.md) | [Español](https://github.com/LuigiD5555/aur_scanner/blob/development/docs/developer/README.dev.es.md)

---

## 🧭 What does this tool do?

This tool takes an AUR package name **or** a GitHub URL and:
- Fetches the PKGBUILD from AUR (plain → snapshot → shallow git as last resort).
- Audits static red flags, HTTPS/allowed domains, checksum policy.
- Verifies sources with `makepkg --verifysource` (when applicable).
- **Strict mode** tightens policies (no weak sums, allowed domains only, PGP when `.sig` exists).
- If everything is clean, installs with `yay -S` (unless `--verify-only`).

> Designed for those who don’t blindly trust AUR: validate first, install later.

---

## 🚀 Quick start

### Drop-in wrapper (transparent)

After installing, it wraps your AUR helper transparently:

```bash
yay -Syu <aur-package>
paru -S <aur-package>
pamac build <aur-package>
```

- If verification fails, the install is aborted with a clear summary.
- If everything passes, your helper proceeds normally.
- To bypass once, you can set: `AUR_GUARD_BYPASS=1` (not recommended).

> **Note:** pacman doesn’t install AUR packages; it’s left untouched.

> All low-level setup is handled by the app. Advanced integration details live in the developer docs.

### ⌨️ Direct CLI (optional for heavy users)

You can also call the verifier directly for finer control:

```bash
aur-scanner <package>
aur-scanner --verify-only <package>
aur-scanner --strict <package>
aur-scanner --fast <package>
aur-scanner https://github.com/OWNER/REPO
```

---

## 🔧 Main options

Every option can be used **either as a flag** or as an **environment variable**:

| Mode              | Flag form           | Env var form      |
|-------------------|--------------------|------------------|
| Verify only       | `--verify-only`    | `VERIFY_ONLY=1`  |
| Fast check        | `--fast`           | `FAST=1`         |
| Strict policies   | `--strict`         | `STRICT=1`       |
| Verbose logging   | `--verbose`        | `VERBOSE=1`      |
| Quiet logging     | `--quiet`          | `QUIET=1`        |

> Example: both `aur-scanner --strict pkg` and `STRICT=1 aur-scanner pkg` do the same.

---

## 🧩 Usage scenarios
This tool adapts to different needs. Here are practical cases to guide you:

### ✅ Normal mode (default)
```bash
aur-scanner <aur-package>
```
- Use for everyday installs of **well-known AUR packages**.
- Balance between safety and speed.
- Auto-fixes weak checksums, warns but doesn’t block minor issues.

### 🛡️ Strict mode

```bash
aur-scanner --strict <aur-package>
```
- For **security-sensitive setups** or **unknown packages**.
- Only HTTPS from allowed domains.
- No weak/skip checksums.
- Requires valid `.sig` files.

### ⚡ Fast mode
```bash
aur-scanner --fast <aur-package>
```
- For **quick previews** without downloads.
- Useful on low bandwidth or when triaging packages.
- Superficial — use cautiously.

### 🔍 Verify-only

```bash
aur-scanner --verify-only <aur-package>
```
- For **auditing packages without installing**.
- Great for CI/CD pipelines.
- Add `DEEP=1` for full source + PGP checks.

### Usage summary

| Mode | Security | Speed | Downloads | Use case |
| --- | --- | --- | --- | --- |
| Normal | Medium | Fast | Yes | Daily installs of common AUR packages |
| Strict | High | Slower | Yes | Unknown packages / sensitive systems |
| Fast | Low | Very fast | No | Quick triage, metadata preview |
| Verify-only | High | Variable | No (default) / Yes (with DEEP=1) without installing anything | Audit only, CI/CD pipelines |

### 🔀 Example workflows

- **Obscure package:** `STRICT=1 aur-scanner my-unknown-pkg`
- **Daily upgrade (yay wrapper):** `yay -Syu`
- **Quick preview while browsing AUR:** `aur-scanner --fast --verify-only <package-name>`
- **Pipeline audit:** `DEEP=1 aur-scanner --verify-only custom-helper-git`

---

## 🧪 What it checks (summary)

- **VCS pinning**: `git+https://…` should use `#commit=` or `#tag=` (strict = required).
- **Source URLs**: enforce HTTPS and validate against an allowlist (strict).
- **Checksums**: prefer `sha256sums`; weak/ `SKIP` are rejected or auto-rewritten (non-strict).
- **PGP**: if `.sig` is declared, `makepkg --verifysource` must pass.
- **Red flags**: highlights risky patterns (diagnostic).

See the full rule set and severity table in the developer docs.

---

## 🛡️ Security notes

- The verifier **does not build** packages; deep checks rely on `makepkg --verifysource`.
- `--fast` is **superficial**; prefer strict+deep checks for sensitive systems.
- Allowlist and red-flag rules can be customized.

---

## ❓ Troubleshooting

- **“Package may not exist”** → confirm name on AUR.
- **“sha256 verification failed”** → upstream changed; do not install until you understand why.
- **“Plain PKGBUILD unavailable while FAST=1”** → rerun without `--fast`.  

More scenarios and logs: see the developer docs.

---

## 🤝 Contributing

Contributions are welcome—code, docs, tests, and rule proposals.  
Good first issues: documentation tweaks, clearer error messages, extra tests.  
See the developer docs for architecture, rules, and test harness.

---

## ☕ Support the project

If this tool saves you time or makes your Arch workflow safer, consider supporting:

[![Support on Ko-fi](https://img.shields.io/badge/Ko--fi-Support%20the%20project-FF5E5B?logo=kofi&logoColor=white)](https://ko-fi.com/luigid5555)

Your support keeps rules up‑to‑date, docs improving, and testing sustainable. Thank you!

---

## License

This project is licensed under the MIT License. See [LICENSE](./LICENSE) for more details.

### Credits

Maintained by the project contributors. See [AUTHORS](./AUTHORS) for credits and acknowledgements.

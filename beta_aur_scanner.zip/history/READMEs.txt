- ./README.md (original):
# AUR Scanner (Bash)

> **Verify first, install later** — Security checker for AUR packages (and GitHub wrappers) with automatic installation via `yay` only if everything passes.

[![Bash](https://img.shields.io/badge/Bash-4EAA25?logo=gnu-bash&logoColor=white)](https://www.gnu.org/software/bash/)
[![Arch Linux](https://img.shields.io/badge/Arch_Linux-1793D1?logo=archlinux&logoColor=white)](https://archlinux.org/)
[![AUR](https://img.shields.io/badge/AUR-1793D1?logo=archlinux&logoColor=white)](https://aur.archlinux.org/)
[![makepkg --verifysource](https://img.shields.io/badge/makepkg--verifysource-enabled-blue)](https://wiki.archlinux.org/title/Makepkg)
[![PGP](https://img.shields.io/badge/PGP-verification-informational?logo=gnupg&logoColor=white)](https://gnupg.org/)
[![sha256](https://img.shields.io/badge/checksums-sha256-success)](https://en.wikipedia.org/wiki/SHA-2)
[![yay](https://img.shields.io/badge/helper-yay-0A0A0A)](https://github.com/Jguer/yay)
[![Ko-fi](https://img.shields.io/badge/Ko--fi-Buy%20me%20a%20coffee-FF5E5B?logo=kofi&logoColor=white)](https://ko-fi.com/luigid5555)


---

🌐 Lea esto en [Español](docs/es/README.es.md)

---

## 📚  Documentation

- Docs index: [Index](docs/INDEX.md)
- Developer docs: [English](https://github.com/LuigiD5555/aur_scanner/blob/development/docs/developer/README.dev.md) | [Español](https://github.com/LuigiD5555/aur_scanner/blob/development/docs/developer/README.dev.es.md)

---

## 🧭 What does this tool do?

This Bash tool takes an AUR package name **or** a GitHub URL and:

1) **Fetches from AUR directly** using the official plain endpoint first. If fetching fails, it retries an alternative endpoint (`tree?plain=1`) and falls back to snapshot or shallow `git clone` only as a last resort.  
2) **Audits** the `PKGBUILD` with static checks and a fast JavaScript parser when Node.js is available (Bash fallbacks otherwise; used automatically).  
3) **Verifies the integrity** of the sources with `makepkg --verifysource`.  
4) **Fixes** weak checksums (e.g., `sha1sums`/`SKIP`) by replacing them with `sha256sums` (only in normal mode; skipped in `--verify-only` and `--fast`).  
5) **(Optional)** **Strengthens** the policy in **strict mode**: allowed domains, no weak checksums, and PGP verification when `.sig` files exist.  
6) If everything is clean, it **installs** automatically with `yay -S` (unless you use `--verify-only`).

> Designed for those who don’t blindly trust AUR: validate first, install later.

---

## 🚀 Quick start

Run it via the modular entrypoint (recommended):

- `sh ./bin/aur-verify <package|GitHub_URL>`
- or `bash bin/aur-verify <package|GitHub_URL>`

Install after verifying an AUR package:

```bash
sh ./bin/aur-verify oreo-nord-cursors-git
```

Verify only (no install):

```bash
sh ./bin/aur-verify --verify-only oreo-nord-cursors-git
```

Strict mode (tighter policies):

```bash
STRICT=1 sh ./bin/aur-verify oreo-nord-cursors-git
```

Fast verification (metadata only, no `makepkg` downloads):

```bash
FAST=1 sh ./bin/aur-verify <AUR-package>
```

Detect and verify from a GitHub repository (finds the AUR wrapper):

```bash
sh ./bin/aur-verify https://github.com/OWNER/REPO
```

Pre-check before installing (aur-guard):

- Explicit invocation (no PATH changes):

```bash
bin/aur-guard yay -S oreo-nord-cursors-git
bin/aur-guard paru -Syu oreo-nord-cursors-git
bin/aur-guard pikaur -S oreo-nord-cursors-git
bin/aur-guard trizen -S oreo-nord-cursors-git
bin/aur-guard pamac build oreo-nord-cursors-git
# pacman does not install AUR; wrapper just delegates
bin/aur-guard pacman -S neovim
```

- Drop-in after creating the symlink to `~/.local/bin/yay`:

```bash
yay -S oreo-nord-cursors-git
paru -Syu oreo-nord-cursors-git
pikaur -S oreo-nord-cursors-git
trizen -S oreo-nord-cursors-git
pamac build oreo-nord-cursors-git
```

### Automatic settings

Run the installer to automatically create the symlinks and ensure the order in the PATH:

```bash
bash scripts/install-aur-guard.sh            # user mode (recommended)
# or
sudo bash scripts/install-aur-guard.sh --system  # system-wide in /usr/local/bin

# Undo symlinks later if needed
bash scripts/uninstall-aur-guard.sh
sudo bash scripts/uninstall-aur-guard.sh --system
```

---

## Intercepting wrapper (aur-guard)

If you want a pre-check before using your usual AUR helpers (yay/paru/pamac), use the universal wrapper and put it at the beginning of your PATH.

Explicit invocation examples:

```bash
bin/aur-guard yay -S <pkg1> <pkg2>
bin/aur-guard paru -Syu <pkg>
bin/aur-guard pamac build <pkg>
```

Drop-in via symlinks (recommended):

```bash
mkdir -p ~/.local/bin
ln -sf "$(pwd)/bin/aur-guard" ~/.local/bin/yay
ln -sf "$(pwd)/bin/aur-guard" ~/.local/bin/paru
ln -sf "$(pwd)/bin/aur-guard" ~/.local/bin/pikaur
ln -sf "$(pwd)/bin/aur-guard" ~/.local/bin/trizen
ln -sf "$(pwd)/bin/aur-guard" ~/.local/bin/pamac
export PATH="$HOME/.local/bin:$PATH"

# Now use your commands as usual
yay -S <aur-package>
paru -S <aur-package>
pamac build <aur-package>
# optional: pacman symlink delegates without AUR verification
 
```

### Automatic setup

Run the installer to create the symlinks automatically and ensure PATH order:

```bash
bash scripts/install-aur-guard.sh            # user mode (recommended)
# or
sudo bash scripts/install-aur-guard.sh --system  # system-wide into /usr/local/bin

# Undo symlinks later if needed
bash scripts/uninstall-aur-guard.sh
sudo bash scripts/uninstall-aur-guard.sh --system
```

Behavior

- Detects target packages and verifies those that exist in AUR via `bin/aur-verify --verify-only` (AUR RPC v5).
- Aborts if any verification fails; otherwise delegates to the real helper with the same arguments.
- Respects knobs like `STRICT=1`, `FAST=1`, `VERBOSE=1`, `QUIET=1` (affecting `bin/aur-verify`).
- To force the real binary path, set `AUR_GUARD_REAL_YAY=/usr/bin/yay` (analogous for PARU/PAMAC).
- To bypass the wrapper temporarily, use `AUR_GUARD_BYPASS=1`.

Helper behavior (transparent)

- The wrapper does not modify helper behavior; it only runs pre-checks and then delegates with the same args.
- For pamac, pre-checks run only on the explicit AUR flow: `pamac build`. Normal `pamac install|upgrade` are left untouched.

Convenience flags (optional)

- You may pass verifier flags with helpers; the wrapper uses them for pre-checks and strips them before delegating:
  - `--strict` (same as `STRICT=1`)
  - `--fast` (same as `FAST=1`)
  - `--verbose` / `--quiet` (same as `VERBOSE=1` / `QUIET=1`)
  - `--metadata` (same as `SHOW_METADATA=1`)
  - `--verify-only` (run pre-checks and do not install via helper)

Developer note: helper list (extendable)

- Extend `lib/guard/helpers.list` to add new helpers or adjust kinds (`pacman` vs `pamac`).

---

## 📦 Requirements

- Arch Linux or derivative with AUR access.  
- Tools: `git`, `curl`, `makepkg` (part of `pacman`), and an AUR helper: `yay` (default).  
  - You can override the yay binary with `YAY_BIN=/path/to/yay`.

```bash
# No installation required; invoke directly with sh or bash
```

---

## 🔧 Options and variables

**Flags**:

- `--verify-only` — Run static checks and exit without installing (no downloads); set `DEEP=1` to include `makepkg --verifysource`.  
- `--deep` — In verify-only, also run `makepkg --verifysource` (downloads sources and verifies checksums/PGP).  
- `--fast` — **Metadata-only** verification (skips `makepkg --verifysource`). ⚠️ With `STRICT=1` it reduces guarantees.  
- `--verbose` — Print full details for advanced users (show function summaries, repository metadata, and expand incident snippets with full context).
- `--quiet` — Minimal logs (only errors and the final verification summary). Overrides `--metadata`.
- `--metadata` — Show repository metadata (`yay -Si`) even in verify-only (hidden by default to keep it fast).
- `-h`/`--help` — Help.

**Environment variables**:

- `STRICT=1` — Enables **strict mode**:
  - **Forbids** `sha1`, `SKIP` or absence of strong checksums.  
  - **Allowlist of domains** (default): `github.com`, `codeload.github.com`, `objects.githubusercontent.com`, `gitlab.com`.  
  - If `.sig` files exist in `source=()`, it **must** pass `makepkg --verifysource` (PGP).  
  - Shows a **summary** of the functions `prepare()`, `build()`, `package()`.  
- `YAY_BIN=/path/to/yay` — Change the yay binary.
- `AUR_FORCE_IPV4=1` — Force IPv4 in all AUR requests (useful when IPv6 routes are flaky/slow).

Reporting and language:

- The final summary report appears in your terminal language (English by default, Spanish when `LANG`/`LC_*` starts with `es`).
- You can force a language with `REPORT_LANG=en` or `REPORT_LANG=es`.
 - `SHOW_FUNCS=1` — Also show `prepare()/build()/package()` summaries; implied by `--verbose`.
 - `SHOW_METADATA=1` — Show repo metadata in verify-only; implied by `--verbose` (or use `--metadata`).
 - `QUIET=1` — Same effect as `--quiet`.

---

## 🧪 Verification modes and depth

Use these knobs to control how deep the verification goes and how much is shown:

- `--verify-only`: Static checks only by default (no downloads, no install).  
  - Add `DEEP=1` to also run `makepkg --verifysource` (downloads sources and verifies checksums/PGP).  
  - Good for CI or when you want integrity checks without installing.
- `--fast`: Metadata-only mode; skips `makepkg --verifysource` and any downloads.  
  - Takes precedence over `DEEP=1` (i.e., `FAST=1` disables deep verification).
- `STRICT=1`: Tightens policies (HTTPS-only, allowed domains, strong checksums, pinning) and upgrades certain WARN into FAIL.  
- `--verbose` / `--quiet`: Increase details (full context, function summaries) or minimize logs (only errors + final summary).

When to use which

- Quick triage (no downloads): `sh ./bin/aur-verify <pkg> --verify-only --fast`
- Integrity without install: `DEEP=1 sh ./bin/aur-verify <pkg> --verify-only`
- Strict gate for security‑sensitive systems: `STRICT=1 DEEP=1 sh ./bin/aur-verify <pkg> --verify-only`
- Detailed auditing: `STRICT=1 sh ./bin/aur-verify <pkg> --verify-only --verbose`
- Minimal noise: `sh ./bin/aur-verify <pkg> --verify-only --quiet`

Notes

- Deep verification (`DEEP=1`) requires network to fetch sources; it is skipped if `--fast` is set.
- In `--verify-only`, checksum auto‑rewrite is not attempted (no `makepkg -g` downloads).
- Installation path still depends on the overall summary; if it’s FAIL and you’re not in verify‑only, installation is aborted.

---

## 🧩 Node CLI: pkgb-parse (optional)

The project ships a modular Node.js CLI to parse PKGBUILD files quickly and feed extra signals into the Bash reports. It is optional: if Node is unavailable, Bash uses grep/awk heuristics.

- Entry point: `bin/pkgb-parse`

Examples:

```bash
# Parse from file
node bin/pkgb-parse --file ./PKGBUILD --summary

# Parse directly from AUR plain URL
node bin/pkgb-parse --url "https://aur.archlinux.org/cgit/aur.git/plain/PKGBUILD?h=zotero"

# JSON for tooling
node bin/pkgb-parse --file ./PKGBUILD --json
```

<details>
<summary><strong>CLI options (details)</strong></summary>

- `--file PATH`: Parse PKGBUILD from a local file
- `--url URL`: Fetch and parse PKGBUILD from URL
- `--summary`: One‑line summary (name, version, counts)
- `--json`: Structured JSON output
- `--signals`: Key=value pairs for Bash integration
- `--redflags-lines`: Red flags as `line<TAB>content`
- `--sources-compact [--limit N]`: Compact sources list, optionally limited

Tip: If you pass an AUR link that is not the plain endpoint, the CLI will suggest the correct `.../plain/PKGBUILD?h=<pkg>` form and prints “Fetching from AUR (respectfully)...”.

</details>

---

## What it checks

### 1) Red flags in `PKGBUILD` (static)

Looks for dangerous or untrustworthy patterns, for example:

- **Self-executing downloads**: `curl|wget ... (sh|bash)`  
- **TCP sockets in shell**: `/dev/tcp`  
- **Dynamic execution**: `eval`, `$(...)`, `` `...` ``, `exec(`  
- **Inline decoding/decryption**: `base64 -d`, `openssl enc -d`  
- **Suspicious privileges/permissions**: `chmod +s`, `setcap`, writing into `/etc`  
- **Path traps**: misuse of `pkgdir` pointing to `/etc`  
- **(STRICT)** one-liners with `python -c`, `perl -e`, `ruby -e`, `node -e`  

> If something is detected, it **fails** with an explanation.

<details>
<summary><strong>Severity and common benign patterns</strong></summary>

- In normal mode, red flags produce a WARN; in `STRICT=1`, they can escalate to FAIL.
- A frequent low‑risk case is using `eval` for architecture‑based variable indirection, e.g.:

  `python -m installer --destdir="$pkgdir" $(eval echo "\${_anki_whl_$CARCH}")`

  This resolves a variable like `_anki_whl_x86_64`. It’s kept as WARN in normal mode; still FAIL in strict mode.

- Deep verification (`DEEP=1`) is not required for this case; it can increase confidence by validating checksums/PGP via `makepkg --verifysource`.

</details>

### 2) Allowed domains for `source=()`

- Accepts (by default): `github.com`, `codeload.github.com`, `objects.githubusercontent.com`, `gitlab.com`.  
- In `STRICT=1`, **rejects** any other domain.

### 3) Checksum policies

- **Normal mode**: if `sha1sums` or `SKIP` are found, the script **downloads sources**, computes `sha256`, and **rewrites** `sha256sums` → re-verifies.  
- **STRICT=1**: **forbids** weak checksums; no autocorrection → **fails**.

### 4) PGP verification (if `.sig` exists)

- If the `PKGBUILD` declares `.sig` files, it **must** pass `makepkg --verifysource`.  
- If **no** `.sig` exists, it warns (not blocked) — in `STRICT=1` the warning is explicit.

### 5) `makepkg --verifysource`

- Runs **without building** (integrity/PGP only).  
- Skipped when using `--verify-only` (static checks) unless you set `DEEP=1`.  
- Skipped with `--fast` (superficial review using `yay -Si` metadata).

### 6) Summary of `prepare()/build()/package()` (STRICT)

- Displays the **first lines** of each function for quick visibility before installing.

### 7) VCS pinning (git+ sources)

- Warns when a `git+https://…` source lacks `#commit=` or `#tag=`. In `STRICT=1`, this causes a failure. This enforces reproducibility for VCS packages.

### 8) Red flags (diagnostics)

- Red flag scanning is available and JS diagnostics print red-flag lines in `--verbose` when Node is present.
- Note: the current runner does not add a red-flags item to the summary; this is diagnostic output only. The atomic `rule_red_flags` exists and can be invoked independently.

### 9) Final summary report (non‑experts)

- Prints a concise, human‑readable summary (PASS/WARN/FAIL/SKIP) with a final “Overall” verdict and the action taken.
- Localized to English/Spanish based on your terminal.

<details>
<summary><strong>Report fields and meanings</strong></summary>

- PKGBUILD Source: where the PKGBUILD came from (AUR snapshot/plain vs git clone fallback)
- VCS pinning: whether `git+…` sources are pinned to `#commit=` or `#tag=`
- Source URLs: checks that all sources use HTTPS
- Allowed domains: validates domains against an allowlist
- Checksums: enforces/remediates checksum policy (sha256)
- Red flags (diagnostic): suspicious patterns (printed in --verbose when JS is available; not part of the summary items)
- makepkg --verifysource: integrity/PGP verification (skipped in verify‑only unless `DEEP=1`)

Status values:

- PASS: everything is fine
- WARN: potentially risky or non‑ideal, but not blocked
- FAIL: blocking issue; installation is aborted
- SKIP: deliberately not run due to mode (verify‑only/fast)

Language control:

- Auto: uses `LANG`/`LC_*` (Spanish when starting with `es`)
- Force: set `REPORT_LANG=es` or `REPORT_LANG=en`

</details>

---

## How it decides to install

- **Input = AUR package name**  

  Fetches `PKGBUILD` from AUR snapshot/plain (no clone), runs checks and, if everything passes, installs with:

  ```bash
  yay -S --noconfirm <pkg>
  ```

- **Input = GitHub URL (`https://github.com/OWNER/REPO`)**  

  Attempts to map to a typical AUR wrapper:
  - `owner-repo`  
  - `owner-repo-bin`  
  - `owner-repo-git`  
  - and detected variants  

  Only accepts if the `PKGBUILD` actually **points to that repo** (check `source`/`url`).

- **`--fast`**  

  Affects verification depth (skips `makepkg --verifysource`) and biases name resolution to prefer `-bin`/`-appimage` candidates when applicable. It does not alter the final install command beyond that.

---

## Input detection (autodetect)

- AUR package URL (`https://aur.archlinux.org/packages/<name>`): extracts `<name>` and fetches from AUR snapshot/plain.
- GitHub URL: derives likely AUR wrapper names (repo title + repo name, plus `-git`/`-bin`/`-appimage`), validates against AUR.
- Bare name: queries the official AUR RPC v5 for an exact hit first; if none, falls back to name‑strict search on `yay -Ss` limited to AUR results.

This approach minimizes trust on local heuristics and uses AUR’s official endpoints wherever possible.

## Examples

Verify and install a cursor from AUR (if it exists):

```bash
sh ./bin/aur-verify oreo-nord-cursors-git
```

Verify only (no install):

```bash
sh ./bin/aur-verify --verify-only oreo-nord-cursors-git
```

Verify an AUR wrapper starting from GitHub:

```bash
sh ./bin/aur-verify https://github.com/OWNER/REPO
```

Force strict mode:

```bash
STRICT=1 sh ./bin/aur-verify <package>
```

Superficial verification (no `makepkg` downloads):

```bash
FAST=1 sh ./bin/aur-verify <package>
```

---

## Architecture

Developer documentation is in `README.dev.md`. See that file for code structure, modules, internals, and diagrams.

---
## Security notes

- This script **does not build** the package during verification (uses `makepkg --verifysource`).  
- It does **not** bypass AUR policies: it automates usual controls (and adds stricter rules if you ask).  
- `--fast` is for **superficial review**; use only if you trust the package/maintainer.  
- Domain allowlist and red flags are **opinionated**; you can tweak them in the script if needed.

---

## Troubleshooting

- **“AUR clone failed (package may not exist)”**  

  Check the package name or if it really exists in AUR.
- **“sha256 verification failed after regeneration”**  

  Upstream changed or there may be an attack; don’t install until you understand why.
- **“source domain not allowed” (STRICT)**  

  Add the domain to the allowlist in the script or install in normal mode (at your discretion).
-- **“Plain PKGBUILD unavailable for '<pkg>' while FAST=1”**  
  
  FAST mode disables snapshot/git fallbacks. Rerun without `--fast` to allow snapshot/git, or try a `-bin`/`-appimage` variant.
\- **“PKGBUILD not found at '<path>/PKGBUILD' (mode=..., pkg=...)”**  
  Run without `--fast` to allow snapshot/git fallback. If it still fails, please open an issue and include the path shown.

---

## Copy‑paste examples

```bash
# Verify and install (normal)
sh ./bin/aur-verify <package>

# Verify only
sh ./bin/aur-verify --verify-only <package>

# Strict mode (whitelisted domains, no weak sums, PGP when .sig exists)
STRICT=1 sh ./bin/aur-verify <package>

# Fast metadata-only verification
FAST=1 sh ./bin/aur-verify <package>

# From GitHub: locate AUR wrapper and verify/install
sh ./bin/aur-verify https://github.com/OWNER/REPO
```

---

## 🤝 Contributing

Contributions of all kinds are very welcome—code, docs, tests, triaging issues, and testing on different Arch setups.

### **How to help quickly**

- 🪳 **Report bugs** with a minimal repro, your Arch variant, and the exact command you ran.
- 🧪 **Test** `STRICT=1`, `FAST=1`, and `DEEP=1` on different AUR packages and share results.
- 📝 **Improve docs** (clarify flags, add examples, Spanish/English parity).
- 🧩 **Suggest rules** (red flags, allowed domains, VCS pinning heuristics).

### **Development setup**

1. Fork + clone this repo.
2. Run locally without installing:

   ```bash
   sh ./bin/aur-verify --verify-only <aur-package>
   STRICT=1 DEEP=1 sh ./bin/aur-verify <aur-package>
   ```

3. Add tests or sample cases as needed (see `docs/developer/README.dev.md`).
4. Open a PR with:

   - Clear description (what/why/how).
   - Before/after behavior (include sample output).
   - Related issue(s), if any.

### **Project hygiene**

- Keep scripts POSIX-friendly when possible; Bash features are OK if justified.
- Prefer small PRs, focused commits, and descriptive messages.
- Follow the security model (never silently relax checks in `STRICT=1`).
- Be kind and constructive.

> Tip: Good first issues often include documentation tweaks, better error messages, or adding tests for edge cases.

---

## ☕ Support the project

If this tool saves you time or makes your Arch workflow safer, consider supporting the work behind it:

[![Support on Ko-fi](https://img.shields.io/badge/Ko--fi-Support%20the%20project-FF5E5B?logo=kofi\&logoColor=white)](https://ko-fi.com/luigid5555)

Your support helps:

- Keep the verification rules up to date with AUR practices.
- Add more test coverage and real-world fixtures.
- Improve documentation and developer tooling
- Explore stricter/safer defaults without hurting usability.

Thank you for helping this stay sustainable 💙

---

## License

This project is licensed under the MIT License. See [LICENSE](./LICENSE) for more details.

### Credits

Maintained by the project contributors. See [AUTHORS](./AUTHORS) for credits and acknowledgements.






- ./README.md (Actualizado):
# AUR Scanner (Bash)

> **Verify first, install later** — Security checker for AUR packages (and GitHub wrappers) with automatic installation via `yay` only if everything passes.

[![Bash](https://img.shields.io/badge/Bash-4EAA25?logo=gnu-bash&logoColor=white)](https://www.gnu.org/software/bash/)
[![Arch Linux](https://img.shields.io/badge/Arch_Linux-1793D1?logo=archlinux&logoColor=white)](https://archlinux.org/)
[![AUR](https://img.shields.io/badge/AUR-1793D1?logo=archlinux&logoColor=white)](https://aur.archlinux.org/)
[![makepkg --verifysource](https://img.shields.io/badge/makepkg--verifysource-enabled-blue)](https://wiki.archlinux.org/title/Makepkg)
[![PGP](https://img.shields.io/badge/PGP-verification-informational?logo=gnupg&logoColor=white)](https://gnupg.org/)
[![sha256](https://img.shields.io/badge/checksums-sha256-success)](https://en.wikipedia.org/wiki/SHA-2)
[![yay](https://img.shields.io/badge/helper-yay-0A0A0A)](https://github.com/Jguer/yay)
[![Ko-fi](https://img.shields.io/badge/Ko--fi-Buy%20me%20a%20coffee-FF5E5B?logo=kofi&logoColor=white)](https://ko-fi.com/luigid5555)

---

🌐 Lea esto en [Español](docs/es/README.es.md)

---

## 📚 Documentation

- Docs index: [Index](docs/INDEX.md)
- Developer docs: [English](https://github.com/LuigiD5555/aur_scanner/blob/development/docs/developer/README.dev.md) | [Español](https://github.com/LuigiD5555/aur_scanner/blob/development/docs/developer/README.dev.es.md)

---

## 🧭 What does this tool do?

This tool takes an AUR package name **or** a GitHub URL and:
- Fetches the PKGBUILD from AUR (tree?plain=1 → snapshot → shallow git as last resort).
- Audits static red flags, HTTPS/allowed domains, checksum policy.
- Verifies sources with `makepkg --verifysource` (when applicable).
- **Strict mode** tightens policies (no weak sums, allowed domains only, PGP when `.sig` exists).
- If everything is clean, installs with `yay -S` (unless `--verify-only`).

> Designed for those who don’t blindly trust AUR: validate first, install later.

---

## 🚀 Quick start

### Drop-in wrapper (transparent)

After installing, it wraps your AUR helper transparently:

```bash
yay -Syu <aur-package>
paru -S <aur-package>
pamac build <aur-package>
```

- If verification fails, the install is aborted with a clear summary.
- If everything passes, your helper proceeds normally.
- To bypass once, you can set: `AUR_GUARD_BYPASS=1` (not recommended).

> **Note:** pacman doesn’t install AUR packages; it’s left untouched.

> All low-level setup is handled by the app. Advanced integration details live in the developer docs.

### ⌨️ Direct CLI (optional for heavy users)

You can also call the verifier directly for finer control:

```bash
aur-scanner <package>
aur-scanner --verify-only <package>
aur-scanner --strict <package>
aur-scanner --fast <package>
aur-scanner https://github.com/OWNER/REPO
```

---

## 🔧 Main options

Every option can be used **either as a flag** or as an **environment variable**:

| Mode              | Flag form           | Env var form    |
|-------------------|--------------------|------------------|
| Verify only       | `--verify-only`    | `VERIFY_ONLY=1`  |
| Fast check        | `--fast`           | `FAST=1`         |
| Strict policies   | `--strict`         | `STRICT=1`       |
| Verbose logging   | `--verbose`        | `VERBOSE=1`      |
| Quiet logging     | `--quiet`          | `QUIET=1`        |

> Example: both `aur-scanner --strict pkg` and `STRICT=1 aur-scanner pkg` do the same.

---

## 🧩 Usage scenarios
This tool adapts to different needs. Here are practical cases to guide you:

### ✅ Normal mode (default)
```bash
# Wrapper
aur-scanner <aur-package>

# Direct CLI
yay -Syu <aur-package>
```

- Use for everyday installs of **well-known AUR packages**.
- Balance between safety and speed.
- Auto-fixes weak checksums, warns but doesn’t block minor issues.

### 🛡️ Strict mode

```bash
# Wrapper
yay -Syu --strict <aur-package>

# Direct CLI
aur-scanner --strict <aur-package>
```

- For **security-sensitive setups** or **unknown packages**.
- Only HTTPS from allowed domains.
- No weak/skip checksums.
- Requires valid `.sig` files.

### ⚡ Fast mode

```bash
# Wrapper
yay -Syu --fast <aur-package>

# Direct CLI
aur-scanner --fast <aur-package>
```

- For **quick previews** without downloads.
- Useful on low bandwidth or when triaging packages.
- Superficial — use cautiously.

### 🔍 Verify-only

```bash
# Wrapper
yay -Syu --verify-only <aur-package>

# Deep verify
DEEP=1 yay -Syu --verify-only <aur-package>

# Direct CLI
aur-scanner --verify-only <aur-package>
DEEP=1 aur-scanner --verify-only <aur-package>
```

- For **auditing packages without installing**.
- Great for CI/CD pipelines.
- Add `DEEP=1` for full source + PGP checks.

### Usage summary

| Mode | Security | Speed | Downloads | Use case |
| --- | --- | --- | --- | --- |
| Normal | Medium | Fast | Yes | Daily installs of common AUR packages |
| Strict | High | Slower | Yes | Unknown packages / sensitive systems |
| Fast | Low | Very fast | No | Quick triage, metadata preview |
| Verify-only | High | Variable | No (default) / Yes (with DEEP=1) without installing anything | Audit only, CI/CD pipelines |

### 🔀 Example workflows

- **Obscure package:** `STRICT=1 aur-scanner my-unknown-pkg`
- **Daily upgrade (yay wrapper):** `yay -Syu`
- **Quick preview while browsing AUR:** `aur-scanner --fast --verify-only <package-name>`
- **Pipeline audit:** `DEEP=1 aur-scanner --verify-only custom-helper-git`

---

## 🧪 What it checks (summary)

- **VCS pinning**: `git+https://…` should use `#commit=` or `#tag=` (strict = required).
- **Source URLs**: enforce HTTPS and validate against an allowlist (strict).
- **Checksums**: prefer `sha256sums`; weak/ `SKIP` are rejected or auto-rewritten (non-strict).
- **PGP**: if `.sig` is declared, `makepkg --verifysource` must pass.
- **Red flags**: highlights risky patterns (diagnostic).

See the full rule set and severity table in the developer docs.

---

## 🛡️ Security notes

- The verifier **does not build** packages; deep checks rely on `makepkg --verifysource`.
- `--fast` is **superficial**; prefer strict+deep checks for sensitive systems.
- Allowlist and red-flag rules can be customized.

---

## ❓ Troubleshooting

- **“Package may not exist”** → confirm name on AUR.
- **“sha256 verification failed”** → upstream changed; do not install until you understand why.
- **“Plain PKGBUILD unavailable while FAST=1”** → rerun without `--fast`.  

More scenarios and logs: see the developer docs.

---

## 🤝 Contributing

Contributions are welcome—code, docs, tests, and rule proposals.  
Good first issues: documentation tweaks, clearer error messages, extra tests.  
See the developer docs for architecture, rules, and test harness.

---

## ☕ Support the project

If this tool saves you time or makes your Arch workflow safer, consider supporting:

[![Support on Ko-fi](https://img.shields.io/badge/Ko--fi-Support%20the%20project-FF5E5B?logo=kofi&logoColor=white)](https://ko-fi.com/luigid5555)

Your support keeps rules up‑to‑date, docs improving, and testing sustainable. Thank you!

---

## License

This project is licensed under the MIT License. See [LICENSE](./LICENSE) for more details.

### Credits

Maintained by the project contributors. See [AUTHORS](./AUTHORS) for credits and acknowledgements. 






- ./docs/developer/README.dev.md:
# Developer Notes (Internal)

Language: English | Español (`README.dev.es.md`)

This document captures implementation details, tuning knobs, and maintenance notes that are intentionally not surfaced in the main README. It is meant for contributors and maintainers.

## Overview Diagrams

<details>
<summary><strong>General Flow (Mermaid)</strong></summary>

```mermaid
flowchart TD
    A[Input] --> B[Resolve to AUR package]
    B --> C{Fetch PKGBUILD}
    C -->|AUR plain OK| D[Checkout dir]
    C -->|plain fail| E[Snapshot]
    E -->|fail| F[Shallow git clone]
    D --> G[Static rules]
    F --> G
    G --> H{Mode}
    H -->|FAST or verify-only w/o DEEP| I[Skip verifysource]
    H -->|FULL or verify-only+DEEP| J[makepkg --verifysource]
    I --> K[Render summary]
    J --> K
    K --> L{Overall}
    L -->|OK & not verify-only| M[Install via yay -S]
    L -->|FAIL or verify-only| N[Exit without install]
```

</details>

<details>
<summary><strong>Overview of the flow (Mermaid)</strong></summary>

```mermaid
%%{init: {"theme": "forest", "handDrawn": true}}%%
sequenceDiagram
    participant User as User
    participant CLI as CLI bin/aur-verify
    participant GitHub as GitHub lib/github/derive_candidates_from_repo.sh
    participant Search as AUR Resolver lib/aur/search_and_resolve.sh
    participant Plain as AUR Plain/RPC lib/aur/fetch_plain_and_snapshot.sh
    participant Verify as Verifier lib/verify/aur_verification_orchestrator.sh
    participant Rules as Rules lib/verify/verification_rules_loader.sh
    participant PKGB as PKGB Utils lib/pkgb/aggregate_pkgb_helpers.sh
    participant Report as Report lib/report/render_summary.sh + lib/i18n/messages.sh
    participant Makepkg as makepkg
    participant Yay as yay

    User->>CLI: Run bin/aur-verify <input>

    %% Input detection
    rect rgba(200, 200, 255, 0.35)
    CLI->>CLI: Detect input type
    alt AUR URL
        CLI->>Plain: Extract name and query RPC v5
        Plain-->>CLI: pkg
    else GitHub URL
        CLI->>GitHub: Derive candidates title/README
        GitHub-->>CLI: Candidate list
        CLI->>Search: Validate on AUR name‑strict
        Search-->>CLI: pkg
    else PackageName
        CLI->>Plain: RPC v5 info exact match
        alt Exact match
            Plain-->>CLI: pkg
        else No exact match
            CLI->>Search: Strict search yay -Ss AUR only
            Search-->>CLI: pkg
        end
    end
    end

    %% Fetch PKGBUILD
    rect rgba(200, 255, 200, 0.35)
    CLI->>Verify: verify_pkgbuild pkg
    Verify->>Plain: Download snapshot/plain PKGBUILD and .SRCINFO
    alt Plain OK
        Plain-->>Verify: Temp path with PKGBUILD
    else Fallback to git
        Verify->>Plain: Plain snapshot failed
        Verify->>CLI: git clone from AUR
        CLI-->>Verify: Cloned repo with PKGBUILD
    end
    Note over Verify: Show PREPARE/BUILD/PACKAGE summaries (Verbose or SHOW_FUNCS)
    end

    %% Static verification atomic rules
    rect rgba(255, 255, 200, 0.35)
    Verify->>Rules: rule_vcs_pinning PKGBUILD
    Rules->>PKGB: pkgb_check_vcs_pinning
    PKGB-->>Rules: Result
    Rules-->>Report: report_add item_vcs_pinning

    Verify->>Rules: rule_sources PKGBUILD
    Rules->>PKGB: list_sources + HTTPS and whitelist checks
    PKGB-->>Rules: Result
    Rules-->>Report: report_add item_source_urls / item_allowed_domains
    Note over Rules,Report: Default → only offending lines; Verbose → show all sources and mark offenders

    Verify->>Rules: rule_checksums PKGBUILD checkout
    Rules->>PKGB: has_weak_or_skip / has_strong_sums
    opt Auto‑fix allowed
        Rules->>Verify: rewrite_sums_to_sha256
    end
    Rules-->>Report: report_add item_checksums
    Note over Rules,Report: Default → only weak/SKIP lines; Verbose → show all checksum arrays and mark weak/SKIP

    Note over Verify: In --verbose, JS prints red-flag lines (diagnostic only)
    end

    %% Deep verification optional
    rect rgba(255, 220, 200, 0.35)
    alt VERIFY-ONLY without DEEP
        Verify->>Rules: rule_verifysource mode verify-only
        Rules-->>Report: SKIP verify‑only
    else FAST
        Verify->>Rules: rule_verifysource mode fast
        Rules-->>Report: SKIP --fast
    else FULL
        Verify->>Makepkg: makepkg --verifysource no build
        Makepkg-->>Verify: OK / FAIL
        Verify->>Rules: rule_verifysource mode full
        Rules-->>Report: PASS / WARN / FAIL
    end
    end

    %% Report and install
    rect rgba(230, 200, 255, 0.35)
    Verify->>Report: report_print mode
    alt OVERALL OK or OK with warnings and not verify-only
        CLI->>Yay: yay -S pkg
        Yay-->>CLI: Installation completed
    else OVERALL FAIL or verify-only
        CLI-->>User: Do not install / Verification only
    end
    Note over CLI,Report: Quiet → suppress info/warn logs; summary remains visible
    end
```

</details>

## Architecture Overview

- Bash entrypoint: `bin/aur-verify`
- Verify orchestrator: `lib/verify/aur_verification_orchestrator.sh` orchestrates the end-to-end flow and installation handoff
- Atomic rules: `lib/verify/verification_rules_loader.sh` aggregates `lib/verify/rules/*.sh`
  - `vcs_pinning_rule.sh`, `sources_rule.sh`, `checksums_rule.sh`, `verifysource_rule.sh` (and `redflags_rule.sh` available; see note below)
- AUR fetchers and RPC helpers: `lib/aur/fetch_plain_and_snapshot.sh`
- AUR search/resolve utilities: `lib/aur/search_and_resolve.sh`
- GitHub wrapper derivation: `lib/github/derive_candidates_from_repo.sh`
- PKGBUILD helpers: `lib/pkgb/aggregate_pkgb_helpers.sh` aggregates:
  - `sources_and_domains.sh`, `checksums_policy.sh`, `redflags_scan.sh`, `functions_summary.sh`
- Report + i18n: `lib/report/render_summary.sh`, `lib/i18n/messages.sh`
- Optional Node parser: `bin/pkgb-parse` with `lib/pkgb/parser/{analysis,utils,outputs,patterns,terminalColors}.js`

## Project Structure (detailed)

Top-level

- `bin/aur-verify`: Main CLI. Parses args/env, orchestrates resolver → checkout → rules → report → optional install.
- `bin/aur-guard`: Wrapper to pre‑check AUR packages before delegating to `yay/paru/pikaur/trizen/pamac`.
- `bin/pkgb-parse`: Optional Node CLI to parse PKGBUILD for diagnostics/compact outputs.
- `scripts/install-aur-guard.sh`: Installs symlinks for aur‑guard into user/system PATH.
- `scripts/uninstall-aur-guard.sh`: Removes aur‑guard helper symlinks (user/system).
- `scripts/run-tests.sh`: Runs bats + Node parser tests (requires `bats` and Node ≥ 18).
- `scripts/validate-sources.sh`: Checks that `source "..."` imports are valid after refactors.

Core libs

- `lib/core/shell_safety.sh`: Strict bash settings, `have_cmd`, `require_tools`, trap setup.
- `lib/utils/logging.sh`: Uniform `[INFO]`, `[WARN]`, `[ERROR]`, `die`, color helpers.

AUR + resolver

- `lib/aur/search_and_resolve.sh`: `resolve_pkg`, name‑strict search via AUR RPC v5 and `yay -Ss` (AUR‑only), GitHub URL candidates.
- `lib/aur/fetch_plain_and_snapshot.sh`: Fetch `PKGBUILD`/`.SRCINFO` via AUR plain/snapshot; fallback to shallow git clone; TTL cache for plain.
- `lib/github/derive_candidates_from_repo.sh`: Parse GitHub URL, read README/title, derive candidate AUR wrapper names.

<details>
<summary><strong>Sequence — Input Resolution</strong></summary>

```mermaid
sequenceDiagram
    participant CLI as bin/aur-verify
    participant Resolver as search_and_resolve.sh
    participant GitHub as derive_candidates_from_repo.sh
    CLI->>Resolver: resolve_pkg(input)
    alt GitHub URL
        Resolver->>GitHub: build_candidates_from_github(url)
        GitHub-->>Resolver: candidates
        Resolver->>Resolver: validate on AUR (RPC v5 / yay -Ss)
    else AUR URL / Name
        Resolver->>Resolver: exact match via RPC v5
        Resolver->>Resolver: strict search via yay -Ss (if needed)
    end
    Resolver-->>CLI: pkg
```

</details>

PKGBUILD helpers

- `lib/pkgb/sources_and_domains.sh`: `list_sources`, HTTPS enforcement, domain allowlist checks.
- `lib/pkgb/checksums_policy.sh`: `has_strong_sums`, `has_weak_or_skip`, `rewrite_sums_to_sha256` (uses `makepkg -g`).
- `lib/pkgb/redflags_scan.sh`: `scan_red_flags` using `lib/rules/redflags.list` (diagnostic lines with numbers).
- `lib/pkgb/functions_summary.sh`: `print_func_summaries` for `prepare()/build()/package()`.
- `lib/pkgb/aggregate_pkgb_helpers.sh`: Facade that composes helpers and `pkgb_check_vcs_pinning`.

<details>
<summary><strong>Sequence — Sources & Checksums</strong></summary>

```mermaid
sequenceDiagram
    participant PKGB as aggregate_pkgb_helpers.sh
    participant Src as sources_and_domains.sh
    participant Sums as checksums_policy.sh
    PKGB->>Src: list_sources()
    Src-->>PKGB: sources stream
    PKGB->>Src: HTTPS/domains checks
    PKGB->>Sums: has_weak_or_skip / has_strong_sums
    alt Auto-rewrite allowed
        PKGB->>Sums: rewrite_sums_to_sha256(dir)
        Sums-->>PKGB: updated PKGBUILD
    end
```

</details>

Verification

- `lib/verify/rules/*.sh`: Atomic rules
  - `vcs_pinning_rule.sh`: Enforce `git+…` pinned via `#commit=`/`#tag=`.
  - `sources_rule.sh`: Enforce HTTPS + allowed domains.
  - `checksums_rule.sh`: Enforce strong sums; optional auto‑rewrite to sha256 (non‑strict/non‑fast).
  - `verifysource_rule.sh`: Run `makepkg --verifysource` depending on mode; interpret result.
  - `redflags_rule.sh`: Available; off by default in summary (diagnostics still available).
- `lib/verify/verification_rules_loader.sh`: Aggregator that exposes `rule_*` calls.
- `lib/verify/aur_verification_orchestrator.sh`: `verify_pkgbuild`, `install_or_verify`, `aur_checkout_to` and overall orchestration.

<details>
<summary><strong>Sequence — Rules & Reporting</strong></summary>

```mermaid
sequenceDiagram
    participant Runner as verify/aur_verification_orchestrator.sh
    participant Rules as verify/verification_rules_loader.sh
    participant Report as report/render_summary.sh
    Runner->>Rules: rule_vcs_pinning
    Rules-->>Runner: status
    Runner->>Rules: rule_sources
    Rules-->>Runner: status
    Runner->>Rules: rule_checksums
    Rules-->>Runner: status
    alt Deep verification
        Runner->>Runner: makepkg --verifysource
    end
    Runner->>Report: report_print(overall)
```

</details>

Internationalization + reporting

- `lib/i18n/messages.sh`: Message catalog (en/es) for report keys.
- `lib/report/render_summary.sh`: Compose and print the localized final summary.

Guard wrapper

- `lib/guard/helpers.list`: Declares known helper names and types (pacman/pamac helpers) for `bin/aur-guard`.
- `lib/rules/redflags.list`: Shared patterns for risky code (used by Bash + Node parser).

<details>
<summary><strong>Sequence — aur-guard Delegation</strong></summary>

```mermaid
sequenceDiagram
    participant User as user
    participant Guard as bin/aur-guard
    participant Verify as bin/aur-verify
    participant Helper as real helper
    User->>Guard: yay/paru/... args
    Guard->>Guard: detect AUR targets
    Guard->>Verify: --verify-only targets
    alt Any FAIL
        Guard-->>User: abort
    else All OK
        Guard->>Helper: exec with original args
        Helper-->>User: normal output
    end
```

</details>

Node PKGB parser (optional)

- `lib/pkgb/parser/analysis.js`: Facade for parser; entry for CLI.
- `lib/pkgb/parser/parser/*.js`: Core parsing pipeline
  - `composePkgbuildParser.js`: Composes passes; exports `parsePKGBUILD`.
  - `spider/*`: Balanced scans for parentheses/braces.
  - `extract*`: Extract arrays and scalars (`source`, checksums, metadata) → meta model.
  - `analyze*`: Domain checks, pin detection; compute signals/severity.
- `lib/pkgb/parser/outputs/modules/*.js`: Renderers for summary, detailed analysis, signals, red‑flag lines, compact sources.
- `lib/pkgb/parser/patterns/*`: Regex composition and loader for shared patterns.
- `lib/pkgb/parser/utils/modules/*`: Network fetch, stdin read, shell‑style tokenization.

Purpose by file (quick map)

- `bin/aur-verify`: CLI args → call `install_or_verify` → inside: `resolve_pkg` → `aur_checkout_to` → rules → summary → maybe install.
- `lib/verify/aur_verification_orchestrator.sh`: Implements the sequence above, provides temp workdir and mode handling.
- `lib/verify/rules/*.sh`: Single‑responsibility checks (status + message key + optional fix).
- `lib/pkgb/*.sh`: Pure helpers; no network except checksum rewrite via `makepkg -g`.
- `lib/aur/*.sh`: Only place that touches network (AUR plain/snapshot/git).
- `bin/aur-guard`: Fronts helpers; calls `bin/aur-verify --verify-only` for AUR targets; delegates unchanged.

Key invariants (for auditing)

- No build occurs during verification; deep checks use `makepkg --verifysource` only.
- Network access limited to AUR endpoints and declared sources (for deep verification); strict mode further constrains allowed domains.
- Automatic checksum rewrite happens only in non‑strict and non‑fast modes and re‑verifies afterward.
- If any rule fails, installation is not attempted.

## Verification Depth and Precedence

- `--verify-only`: static checks only (no install). With `DEEP=1` it also runs `makepkg --verifysource`.
- `--fast`: metadata-only; skips deep verification even if `DEEP=1` is set (FAST wins over DEEP).
- `STRICT=1`: tightens policies (HTTPS-only, domain allowlist, strong checksums, VCS pinning) and may elevate WARN to FAIL.

## Logging Modes

- `--verbose` (or `VERBOSE=1`):
  - Implies `SHOW_FUNCS=1`
  - Prints compact sources list from JS parser, summary line, and red flags lines (diagnostics only).
- `--quiet` (or `QUIET=1`):
  - Suppresses info/warn logs globally; summary and errors remain.
  - Overrides `--verbose` and disables `SHOW_FUNCS`/metadata.
- Function summaries can also be shown explicitly with `SHOW_FUNCS=1` regardless of `--verbose`.

## Performance Tweaks (Internal)

- JS parser single-shot: `rule_js_signals` invokes the Node parser once and exports counts; `rule_red_flags` reuses them and only renders lines in `--verbose` (no extra Node launches).
- Fetch plain first: always try AUR `plain/PKGBUILD?h=<pkg>`, then fallback to `tree/PKGBUILD?plain=1`, finally snapshot or shallow git clone.
- Robust network path: curl helpers try default stack and fallback to IPv4 automatically; honor `AUR_FORCE_IPV4=1` to force IPv4.
- Plain availability check: even if checkout falls back to snapshot/git, `aur_plain_exists` uses HEAD to mark availability accurately in the report.
- Skip heavy downloads in verify-only: checksum auto‑rewrite via `makepkg -g` is disabled when `VERIFY_ONLY=1` (still enabled in full mode unless `FAST=1`).
- `.SRCINFO` is fetched only in VERBOSE or STRICT.
- Plain PKGBUILD caching via `/tmp` with TTL (env: `AUR_CACHE_DIR`, `AUR_CACHE_TTL_SEC`).

## Red Flags Handling

- The atomic rule `rule_red_flags()` prefers the Node parser when present. It uses the exported JS count to avoid an extra parse, and prints detailed lines only in `--verbose`.
- Policy treats the arch-selection `eval` pattern as low risk (WARN normal / FAIL strict); other patterns WARN/FAIL accordingly.

## Node Parser Integration (`bin/pkgb-parse`)

- Optional: used opportunistically when Node is present; otherwise safe stubs are loaded.
- Provided outputs used by the Bash CLI:
  - `--summary`, `--sources-compact`, and `--redflags-lines` (diagnostics only)
- ESM modules live under `lib/pkgb/parser`; parsing and formatting concerns are separated.

## Adding/Adjusting Rules

- Prefer small, composable functions in `lib/verify/rules/*.sh` that:
  - Log only snippets (full context in VERBOSE)
  - Update the report via `report_add <item> <STATUS> <message_key>`
  - Return non-zero only when the rule should contribute to failure
- Add user-facing messages in `lib/i18n/messages.sh` (both EN and ES).

## Tests and Local Tips

- Run tests (requires bats + Node ≥ 18):
  - `scripts/run-tests.sh`
  - Or directly: `bats tests` + `node --test tests/js`

- Quick loop on a target package:
  - `STRICT=1 sh ./bin/aur-verify <pkg> --verify-only --verbose`
  - `FAST=1 sh ./bin/aur-verify <pkg> --verify-only`
  - `DEEP=1 sh ./bin/aur-verify <pkg> --verify-only`
- Quick pre-check before install (aur-guard):
  - Explicit: `bin/aur-guard yay -S <pkg>` (likewise for paru/pikaur/trizen, `pamac build <pkg>`)
  - Drop-in: symlink `bin/aur-guard` to `~/.local/bin/{yay,paru,pikaur,trizen,pamac}`
- Clear cache to re-fetch a PKGBUILD:
  - `rm -f /tmp/aur-plain-cache/<pkg>.PKGBUILD`

## Release/Docs Notes

- Keep README focused on usage and stable flags. Place internal tuning and rationale here.
- Do not link this file from README unless intentionally surfacing to users.

## DRY and Ownership of Rules

- Red flags list: `lib/rules/redflags.list`
  - Bash: `lib/pkgb/redflags_scan.sh` -> `scan_red_flags()` (`grep -E -f`)
  - JS: `lib/pkgb/parser/patterns/compileRegexPatterns.js` loads the same list
- Enforcement (PASS/WARN/FAIL) is in Bash rules. JS parser is diagnostics-only.

## Bash Layout (modular)

- Core: `lib/core/shell_safety.sh`
- Logging: `lib/utils/logging.sh`
- AUR fetchers: `lib/aur/fetch_plain_and_snapshot.sh`
- AUR search/resolve: `lib/aur/search_and_resolve.sh`
- GitHub candidates: `lib/github/derive_candidates_from_repo.sh`
  - Repo metadata (optional): pulled via `$YAY_BIN -Si` when helper is present
- PKGBUILD helpers: `lib/pkgb/{sources_and_domains,checksums_policy,redflags_scan,functions_summary}.sh` (aggregated by `aggregate_pkgb_helpers.sh`)
- Verify rules: `lib/verify/rules/*.sh` (aggregated by `lib/verify/verification_rules_loader.sh`)
- Verify orchestrator: `lib/verify/aur_verification_orchestrator.sh`
- i18n: `lib/i18n/messages.sh`
- Report: `lib/report/render_summary.sh`

### Import sanity check after refactors

Run `bash scripts/validate-sources.sh` to validate all `source "..."` references point to existing files.
Optionally, add a `.git/hooks/pre-commit` hook to invoke that script.

The script resolves `$SCRIPT_DIR`/`$LIB_DIR` heuristically and validates module existence. Handy after renames/moves.

## Function Reference (concise)

<details>
<summary><strong>Verifier runner and rules</strong></summary>

- `verify_pkgbuild(pkg)`: Orchestrates checkout, rules, reporting, and optional install.
- `install_or_verify(pkg)`: Shows metadata in verify-only (when enabled) and calls `verify_pkgbuild`.
- `aur_checkout_to(pkg, workdir)`: Fetches PKGBUILD via AUR plain → snapshot → git fallback.

- `rule_vcs_pinning(pkgb, strict)`: Enforce pinning for `git+` sources (`#commit=`/`#tag=`).
- `rule_sources(pkgb, strict)`: Enforce HTTPS-only and allowed domains.
- `rule_checksums(pkgb, checkout, strict, fast)`: Enforce strong sums; auto-rewrite to sha256 unless strict/fast.
- `rule_verifysource(checkout, mode, strict)`: Run `makepkg --verifysource` depending on mode; WARN vs FAIL in strict.
- `rule_red_flags(pkgb, strict)`: Available rule; not currently included in the default runner summary.

</details>

## Execution Steps (end‑to‑end)

1) Input resolve: detect if token is AUR name, AUR URL or GitHub URL; resolve to AUR package name (strict name search).
2) Checkout: fetch `PKGBUILD` and optionally `.SRCINFO` from AUR plain; fallback to snapshot; last resort shallow git clone.
3) Static rules: VCS pinning → sources (HTTPS/domains) → checksums (and optional rewrite) → optional red‑flags diagnostics.
4) Deep verification (conditional): run `makepkg --verifysource` depending on mode (`DEEP`, `FAST`, `verify‑only`).
5) Reporting: produce localized human summary with itemized PASS/WARN/FAIL/SKIP and overall verdict.
6) Install decision: if overall OK and not verify‑only, install via `yay -S` (or configured helper).

Mode switches and precedence

- `FAST=1` disables deep verification even if `DEEP=1` is set.
- `STRICT=1` upgrades certain WARN to FAIL and forbids weak checksums and disallowed domains.
- `--verify-only` avoids install; deep checks only if `DEEP=1` and not `FAST=1`.

## Auditing Checklist

- Inputs: confirm resolver maps only to existing AUR packages; GitHub URL mapping validated against `source/url`.
- Network: confirm only AUR endpoints and declared `source=()` are accessed; no arbitrary curl/wget execution.
- Checksums: confirm sha256 policy; in non‑strict, confirm rewrite logs and re‑verification.
- PGP: when `.sig` exists, confirm `makepkg --verifysource` result gates install.
- Domains: confirm HTTPS‑only and allowlist enforcement in strict mode.
- VCS pinning: confirm all `git+` sources are pinned (strict FAIL otherwise).
- Logging: confirm summary accurately reflects rule statuses and modes.

## Optimization Opportunities

- Cache: tune `AUR_CACHE_TTL_SEC` for plain PKGBUILD reuse; persist across runs when appropriate.
- Parallelism: pre‑compute compact sources via Node parser (if available) while fetching plain files.
- I/O: minimize repeated `yay -Si` by gating behind `--metadata` or caching.
- Red‑flags: feed parser signals to guide which rules to expand in verbose mode.
- Resolution: bias name resolution based on context (`-bin`/`-appimage`) in fast mode to avoid deep downloads.

## Diagrams

<details>
<summary><strong>Overview of the flow (Mermaid)</strong></summary>

```mermaid
%%{init: {"theme": "forest", "handDrawn": true}}%%
sequenceDiagram
    participant User as User
    participant CLI as CLI bin/aur-verify
    participant GitHub as GitHub lib/github/derive_candidates_from_repo.sh
    participant Search as AUR Resolver lib/aur/search_and_resolve.sh
    participant Plain as AUR Plain/RPC lib/aur/fetch_plain_and_snapshot.sh
    participant Verify as Verifier lib/verify/aur_verification_orchestrator.sh
    participant Rules as Rules lib/verify/verification_rules_loader.sh
    participant PKGB as PKGB Utils lib/pkgb/aggregate_pkgb_helpers.sh
    participant Report as Report lib/report/render_summary.sh + lib/i18n/messages.sh
    participant Makepkg as makepkg
    participant Yay as yay

    User->>CLI: Run bin/aur-verify <input>

    %% Input detection
    rect rgba(200, 200, 255, 0.35)
    CLI->>CLI: Detect input type
    alt AUR URL
        CLI->>Plain: Extract name and query RPC v5
        Plain-->>CLI: pkg
    else GitHub URL
        CLI->>GitHub: Derive candidates from title/README
        GitHub-->>CLI: Candidate list
        CLI->>Search: Validate on AUR (name‑strict)
        Search-->>CLI: pkg
    else PackageName
        CLI->>Plain: RPC v5 info exact match
        alt Exact match
            Plain-->>CLI: pkg
        else No exact match
            CLI->>Search: Strict search yay -Ss (AUR only)
            Search-->>CLI: pkg
        end
    end
    end

    %% Fetch PKGBUILD
    rect rgba(200, 255, 200, 0.35)
    CLI->>Verify: verify_pkgbuild pkg
    Verify->>Plain: Download AUR plain PKGBUILD and .SRCINFO
    alt Plain OK
        Plain-->>Verify: Temp path with PKGBUILD
    else Fallback to git
        Verify->>Plain: Plain snapshot failed
        Verify->>CLI: git clone from AUR
        CLI-->>Verify: Cloned repo with PKGBUILD
    end
    Note over Verify: Show PREPARE/BUILD/PACKAGE summaries (VERBOSE or SHOW_FUNCS)
    end

    %% Static verification atomic rules
    rect rgba(255, 255, 200, 0.35)
    Verify->>Rules: rule_vcs_pinning PKGBUILD
    Rules->>PKGB: pkgb_check_vcs_pinning
    PKGB-->>Rules: Result
    Rules-->>Report: report_add item_vcs_pinning

    Verify->>Rules: rule_sources PKGBUILD
    Rules->>PKGB: list_sources + HTTPS and allowlist checks
    PKGB-->>Rules: Result
    Rules-->>Report: report_add item_source_urls / item_allowed_domains
    Note over Rules,Report: Default → only offenders; VERBOSE → list all and mark offenders

    Verify->>Rules: rule_checksums PKGBUILD checkout
    Rules->>PKGB: has_weak_or_skip / has_strong_sums
    opt Auto‑fix allowed
        Rules->>Verify: rewrite_sums_to_sha256
    end
    Rules-->>Report: report_add item_checksums
    Note over Rules,Report: Default → only weak/SKIP; VERBOSE → show all arrays and mark weak/SKIP

    Note over Verify: In --verbose, JS prints red‑flag lines (diagnostic)
    end

    %% Deep verification optional
    rect rgba(255, 220, 200, 0.35)
    alt VERIFY‑ONLY without DEEP
        Verify->>Rules: rule_verifysource mode verify‑only
        Rules-->>Report: SKIP verify‑only
    else FAST
        Verify->>Rules: rule_verifysource mode fast
        Rules-->>Report: SKIP --fast
    else FULL
        Verify->>Makepkg: makepkg --verifysource (no build)
        Makepkg-->>Verify: OK / FAIL
        Verify->>Rules: rule_verifysource mode full
        Rules-->>Report: PASS / WARN / FAIL
    end
    end

    %% Report and install
    rect rgba(230, 200, 255, 0.35)
    Verify->>Report: report_print mode
    alt OVERALL OK and not verify‑only
        CLI->>Yay: yay -S pkg
        Yay-->>CLI: Installation completed
    else OVERALL FAIL or verify‑only
        CLI-->>User: Do not install / Verification only
    end
    Note over CLI,Report: QUIET → suppress info/warn; summary stays visible
    end
```

</details>

<details>
<summary><strong>Autodetection and Fetch (Mermaid)</strong></summary>

```mermaid
%%{init: {"theme": "forest", "handDrawn": true}}%%
flowchart TD
    A[Input: AUR URL / GitHub URL / PackageName]
    B{Type?}
    A --> B
    B -->|AUR URL| C[Extract <name> from URL]
    C --> H[Package name]
    B -->|GitHub URL| D[Derive candidates from README/title]
    D --> E[Strict AUR validation via lib/search.sh]
    E --> H
    B -->|Name| F{AUR RPC exact match?}
    F -->|Yes| H
    F -->|No| G[Strict name search via yay -Ss <AUR only>]
    G --> H

    H --> I{Fetch PKGBUILD}
    I -->|Plain OK| J[AUR snapshot/plain <no git>]
    I -->|Plain failed| K[Shallow git clone from AUR]
    J --> L[Static checks <rules>]
    K --> L

    classDef ok fill:#e0ffe0,stroke:#9acd32,stroke-width:1px;
    classDef alt fill:#e6f0ff,stroke:#4f81bd,stroke-width:1px;
    classDef warn fill:#fff7cc,stroke:#ffc107,stroke-width:1px;
    class J ok;
    class K alt;
    class L warn;
```

</details>

<!-- Focused, navigable diagrams for each phase of the general flow -->

<details>
<summary><strong>Input detection — zoom‑in</strong></summary>

```mermaid
flowchart TD
    IN[Input token] --> T{Type}
    T -->|AUR URL| A[Extract <name>]
    T -->|GitHub URL| G[Build AUR candidates]
    T -->|Name| N[Check AUR RPC exact]
    G --> V[Validate on AUR (strict name)]
    N -->|Hit| P[Package]
    N -->|Miss| S[Strict search yay -Ss AUR only]
    V --> P
    S --> P
```

</details>

<details>
<summary><strong>Fetch PKGBUILD — zoom‑in</strong></summary>

```mermaid
flowchart TD
    Pkg[Resolved package] --> F{Fetch}
    F -->|plain OK| PLAIN[AUR plain: PKGBUILD/.SRCINFO]
    F -->|plain fail| ALT[tree/PKGBUILD?plain=1]
    ALT -->|ok| PLAIN
    ALT -->|fail| SNAP[Snapshot tarball]
    SNAP -->|fail| GIT[Shallow git clone]
    PLAIN --> OUT[Checkout dir]
    GIT --> OUT
```

</details>

<details>
<summary><strong>Static verification atomic rules — zoom‑in</strong></summary>

```mermaid
flowchart TD
    Start[PKGBUILD path] --> VCS[VCS pinning rule]
    VCS --> SRC[Ssl/Domain rules]
    SRC --> SUMS[Checksums rule]
    SUMS --> DIAG[Red‑flags diagnostics (optional)]
    DIAG --> RPT[Report items updated]
```

</details>

<details>
<summary><strong>Deep verification optional — zoom‑in</strong></summary>

```mermaid
flowchart TD
    Mode{Mode} -->|FAST| Skip[SKIP verifysource]
    Mode -->|verify‑only & !DEEP| Skip
    Mode -->|FULL or (verify‑only & DEEP)| MK[makepkg --verifysource]
    MK --> OK[PASS/WARN/FAIL → report]
```

</details>

<details>
<summary><strong>Report and install — zoom‑in</strong></summary>

```mermaid
flowchart TD
    Items[Rule items] --> Sum[Render summary (i18n)]
    Sum --> DEC{Overall}
    DEC -->|OK & not verify‑only| Install[yay -S <pkg>]
    DEC -->|FAIL or verify‑only| Exit[No install]
```

</details>

<details>
<summary><strong>AUR Guard — Interception</strong></summary>

```mermaid
flowchart TD
    UserCmd[User helper cmd] --> Guard[bin/aur-guard]
    Guard --> Parse[Parse args + detect AUR targets]
    Parse --> Verify[Run bin/aur-verify --verify-only for AUR targets]
    Verify -->|Any FAIL| Abort[Abort delegation]
    Verify -->|All OK| Delegate[Exec real helper with original args]
```

</details>

<details>
<summary><strong>Node Parser — Pipeline</strong></summary>

```mermaid
sequenceDiagram
    participant CLI as pkgb-parse
    participant Parser as composePkgbuildParser
    participant Spider as spider/*
    participant Extract as extract*
    participant Analyze as analyze*
    participant Outputs as outputs/*

    CLI->>Parser: parsePKGBUILD(input)
    Parser->>Spider: crawl balanced () and {}
    Spider-->>Parser: token stream / spans
    Parser->>Extract: arrays (source, sums) + scalars
    Extract-->>Parser: meta model
    Parser->>Analyze: domains, pins, severity
    Analyze-->>Parser: signals
    Parser->>Outputs: render summary / compact sources / redflags lines
    Outputs-->>CLI: text / JSON / signals
```

</details>

<details>
<summary><strong>PKGBUILD helpers</strong></summary>

- `list_sources()`: Extract sources array (normalized, stripped).
- `sources_have_only_https()`: Test stream for HTTPS-only.
- `sources_domains_allowed()`: Test stream against allowlist.
- `has_strong_sums()`, `has_weak_or_skip()`: Detect checksum policy.
- `rewrite_sums_to_sha256(dir)`: Use `makepkg -g` and rewrite checksum arrays.
- `scan_red_flags(pkgb)`: Grep against `lib/rules/redflags.list` with line numbers.
- `print_func_summaries(pkgb)`: Extract prepare/build/package snippet bodies.
- `pkgb_check_vcs_pinning(pkgb)`: Check for unpinned VCS sources.

</details>

<details>
<summary><strong>AUR/GitHub and resolver</strong></summary>

- `aur_plain_fetch_plain_files`, `aur_plain_fetch_repo`: Fetch PKGBUILD/.SRCINFO or snapshot tarball.
- `aur_plain_rpc_info|search|exists`: RPC helpers and discovery.
- `resolve_pkg(input)`: Resolve an input token or GitHub URL to an AUR package name.
- `aur_search_name_strict_aur_only`, `prefer_fast_variant`: Name-strict search and fast-variant biasing.
- `is_github_url`, `build_candidates_from_github`, `github_default_branch`: Wrapper candidate derivation.

</details>
## Versioning and Changelog

This project is delivered as scripts; we record notable changes here for contributors. Dates are UTC.

- 2025-09-04
  - JS parser integration performance: added `lib/pkgb/js_parser_bridge.sh` and `rule_js_signals` so the Node parser runs once per verification; `rule_red_flags` reuses exported counts and only renders lines in `--verbose`.
  - AUR fetch robustness: fetch flow is now `plain` → `tree?plain=1` → `snapshot` → `git` (last resort). `aur_plain_exists` uses HEAD and the summary marks plain availability correctly even after fallbacks.
  - Network resilience: IPv4 fallback added to AUR requests; env `AUR_FORCE_IPV4=1` forces IPv4 for all AUR calls.
  - Verify-only efficiency: checksum auto-rewrite via `makepkg -g` is skipped in `VERIFY_ONLY=1`; `.SRCINFO` fetched only in VERBOSE/STRICT.
  - Summary/report: added explicit PASS for “Plain PKGBUILD availability” when the URL responds even if checkout used snapshot/git.
  - File naming: renamed `lib/verify/runner.sh` → `lib/verify/aur_verification_orchestrator.sh`, `lib/verify/rules.sh` → `lib/verify/verification_rules_loader.sh`; docs renamed to `README.dev.md`, `README.dev.es.md`, `README.md`, `README.es.md`, and `docs/INDEX.md`.
  - Diagrams/docs updated to reflect new fetch step (`tree?plain=1`) and module names.

Versioning policy

- Breaking CLI flags or behavior will be called out explicitly in this section. Internal refactors that don’t change user-facing flags are grouped under performance/robustness.

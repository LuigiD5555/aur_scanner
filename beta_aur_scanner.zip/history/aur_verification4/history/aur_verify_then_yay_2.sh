#!/usr/bin/env bash
# aur_verify_then_yay.sh
# -------------------------------------------------------------
# Purpose:
#   Verify an AUR package *without building*. If clean, install with `yay -S`.
#   Normal mode: if PKGBUILD uses weak sums (sha1) or SKIP, auto-download sources,
#                compute sha256 and rewrite to sha256sums, then re-verify.
#   STRICT mode: enforce hard rules (see below), do NOT auto-fix; abort on violations.
#
# STRICT mode adds:
#   - PGP enforcement if .sig sources are present (must pass `makepkg --verifysource`).
#   - Forbid checksum weaknesses outright: sha1, SKIP, or no strong sums.
#   - Whitelist allowed source domains (default: github.com, codeload.github.com,
#     objects.githubusercontent.com, gitlab.com). Everything else is rejected.
#   - Expanded red-flag patterns (python -c, perl -e, ruby -e, node -e, exec with eval-like use).
#   - Prints a short summary of PKGBUILD functions (prepare/build/package) before install.
#
# Discovery (safe URL→AUR resolution):
#   - If input is a GitHub URL: extract owner/repo, fetch README title, derive a kebab-case
#     candidate (e.g., "Sticky Notes" -> "sticky-notes") plus repo name, and test AUR existence.
#   - If no exact AUR match: strict AUR name-only search (regex anchored), AUR-only, then pick.
#
# Usage:
#   sh ./aur_verify_then_yay.sh [--verify-only] [--fast] [--strict] <aur_pkg | github_url>
#   sh ./aur_verify_then_yay.sh appname-from-aur
#   sh ./aur_verify_then_yay.sh "https://github.com/<owner>/<repo>.git"
#
# Env:
#   YAY_BIN=</path/to/yay>  # default: "yay"
#   STRICT=1                # enable strict mode (paranoia-friendly)
#   VERIFY_ONLY=1           # do all checks but DO NOT install
#   FAST=1                  # metadata-only checks (skip source downloads)
#   NO_PROMPT=1             # if multiple AUR matches, print and exit non-zero
# -------------------------------------------------------------

set -euo pipefail

# Ensure bash is used (script relies on bash arrays/mapfile)
if [ -z "${BASH_VERSION:-}" ]; then
  exec bash "$0" "$@"
fi

YAY_BIN="${YAY_BIN:-yay}"
STRICT="${STRICT:-0}"
VERIFY_ONLY="${VERIFY_ONLY:-0}"
FAST="${FAST:-0}"
NO_PROMPT="${NO_PROMPT:-0}"

# --- Logging to STDERR to avoid contaminating stdout captures ---
log_info()  { printf '[INFO] %s\n' "$*" >&2; }
log_warn()  { printf '[WARN] %s\n' "$*" >&2; }
log_error() { printf '[ERROR] %s\n' "$*" >&2; }
die()       { log_error "$*"; exit 1; }

have_cmd() { command -v "$1" >/dev/null 2>&1; }
require_tools() { for c in "$@"; do have_cmd "$c" || die "Missing required command: $c"; done; }
require_tools "$YAY_BIN" git sed awk tr grep cut head sort uniq curl tar makepkg sha256sum

# --- yay helpers (compat: no --aur/--repo switches; read Repository:) ---
yay_query_any() { "$YAY_BIN" -Si "$1" 2>/dev/null; }

yay_field() { # $1=pkg  $2=Field Name
  local out
  out="$(yay_query_any "$1")" || return 1
  printf '%s\n' "$out" | sed -n "s/^$2[[:space:]]*:[[:space:]]*//p" | head -n1
}

yay_repo_of()    { yay_field "$1" "Repository" | tr '[:upper:]' '[:lower:]'; }
yay_exists_any() { yay_query_any "$1" >/dev/null; }
yay_exists_aur() { [ "$(yay_repo_of "$1")" = "aur" ]; }

# --- GitHub URL parsing & README scraping ---
is_github_url() { [[ "$1" =~ ^https?://github\.com/[^/]+/[^/]+(\.git)?/?$ ]]; }

github_owner_repo() { # prints "owner repo"
  local url="$1" path owner repo
  path="${url#https://github.com/}"; path="${path#http://github.com/}"
  path="${path%%\?*}"; path="${path%%#*}"; path="${path%/}"; path="${path%.git}"
  owner="${path%%/*}"; repo="${path##*/}"
  printf '%s %s\n' "$owner" "$repo"
}

github_default_branch() { # $1=owner $2=repo -> prints branch or empty
  git ls-remote --symref "https://github.com/$1/$2" HEAD 2>/dev/null \
    | awk '/^ref:/ {print $2}' | sed -n 's@^refs/heads/@@p' | head -n1
}

try_fetch_readme() { # $1=owner $2=repo $3=branch -> prints README or empty
  local owner="$1" repo="$2" br="$3" url content
  for name in README.md README.rst README.txt README; do
    url="https://raw.githubusercontent.com/${owner}/${repo}/${br}/${name}"
    if content="$(curl -fsSL "$url" 2>/dev/null)"; then
      printf '%s\n' "$content"; return 0
    fi
  done
  return 1
}

extract_title_from_readme() { # stdin -> title-ish line
  local data title
  data="$(cat)"
  title="$(printf '%s\n' "$data" | sed -n 's/^#[[:space:]]\{0,1\}//p' | head -n1)"
  if [ -n "$title" ]; then printf '%s\n' "$title"; else
    printf '%s\n' "$data" | sed -n '/[^[:space:]]/ {s/^[[:space:]]*//;p; q;}'
  fi
}

normalize_kebab() { # "Sticky Notes!" -> "sticky-notes"
  printf '%s' "$1" \
    | tr '[:upper:]' '[:lower:]' \
    | sed 's/[^a-z0-9[:space:]-]/ /g' \
    | tr ' ' '-' | tr -s '-'
}

# Prefer README-derived base first, then repo name (so "sticky-notes" wins over "sticky")
build_candidates_from_github() { # $1=url
  local url="$1" owner repo branch title kebab
  read -r owner repo <<<"$(github_owner_repo "$url")" || return 0
  branch="$(github_default_branch "$owner" "$repo")"; [ -z "$branch" ] && branch="main"
  log_info "GitHub repo: $owner/$repo (branch: $branch)"

  local readme=""
  if readme="$(try_fetch_readme "$owner" "$repo" "$branch" 2>/dev/null)"; then
    title="$(printf '%s' "$readme" | extract_title_from_readme | head -n1 | tr -d '\r')"
    [ -n "$title" ] && log_info "README title: $title"
    kebab="$(normalize_kebab "$title")"
  else
    log_warn "Unable to fetch README; falling back to repo name only."
  fi

  local -a base out
  base=()
  [ -n "${kebab:-}" ] && base+=("$kebab")
  base+=("$(normalize_kebab "$repo")")
  mapfile -t base < <(printf '%s\n' "${base[@]}" | grep -E '.+' | awk '!seen[$0]++')

  out=()
  for b in "${base[@]}"; do
    out+=("$b" "${b}-git" "${b}-bin" "${b}-appimage")
  done

  printf '%s\n' "${out[@]}" | awk '!seen[$0]++'
}

prefer_fast_variant() { # stdin -> reordered list
  awk '{
    a[NR]=$0
  } END {
    for(i=1;i<=NR;i++) if (a[i] ~ /-bin$/ || a[i] ~ /-appimage$/) print a[i]
    for(i=1;i<=NR;i++) if (!(a[i] ~ /-bin$/ || a[i] ~ /-appimage$/)) print a[i]
  }'
}

# Alternative simpler AUR search that doesn't rely on helper functions
aur_search_simple() { # $1=search_term $2=regex -> print only AUR pkgs
  local term="$1" pattern="$2"
  log_info "Simple AUR search for: '$term' with pattern: '$pattern'"
  
  "$YAY_BIN" -Ss "$term" 2>/dev/null | awk -v pat="$pattern" '
    /^aur\// { 
      # Extract package name 
      line = $0
      sub(/^aur\//, "", line)
      split(line, parts, " ")
      pkg_name = parts[1]
      if (pkg_name != "" && pkg_name ~ pat) {
        print pkg_name
      }
    }
  ' | sort -u
}

# Fixed AUR search function - use yay -Ss instead of -Ssq and parse properly
aur_search_name_strict_aur_only() { # $1=search_term $2=regex -> print only AUR pkgs
  local term="$1" pattern="$2"
  log_info "Searching AUR for term: '$term' with pattern: '$pattern'"
  
  # Debug: show what yay -Ss returns
  local search_output
  search_output="$("$YAY_BIN" -Ss "$term" 2>/dev/null)" || {
    log_warn "yay -Ss '$term' failed or returned no results"
    return 1
  }
  
  if [ -z "$search_output" ]; then
    log_warn "yay -Ss '$term' returned empty output"
    return 1
  fi
  
  log_info "Raw search output for debugging:"
  printf '%s\n' "$search_output" | head -5 | sed 's/^/  DEBUG: /' >&2
  
  # Try simple approach first
  local simple_results
  simple_results="$(aur_search_simple "$term" "$pattern")"
  if [ -n "$simple_results" ]; then
    log_info "Simple search found results, using those"
    printf '%s\n' "$simple_results"
    return 0
  fi
  
  # Fallback to more complex verification
  printf '%s\n' "$search_output" | awk '
    /^aur\// { 
      # Extract package name from lines like "aur/package-name version (votes popularity)"
      line = $0
      sub(/^aur\//, "", line)
      split(line, parts, " ")
      pkg_name = parts[1]
      if (pkg_name != "") {
        print pkg_name
      }
    }
  ' | grep -E "$pattern" | sort -u | while read -r name; do
    log_info "Checking candidate: '$name'"
    # Double-check that it exists and is from AUR
    if yay_exists_any "$name" && [ "$(yay_repo_of "$name")" = "aur" ]; then
      printf '%s\n' "$name"
    else
      log_warn "Candidate '$name' failed verification"
    fi
  done
}

select_from_list() { # stdin list -> chosen (menu on stderr, choice on stdout)
  local -a items; mapfile -t items
  [ "${#items[@]}" -gt 0 ] || return 1
  if [ "$NO_PROMPT" = "1" ]; then
    log_warn "Multiple candidates (NO_PROMPT=1):"
    printf '  - %s\n' "${items[@]}" >&2
    return 2
  fi
  echo "Select a package:" >&2
  local i; for i in "${!items[@]}"; do printf ' [%d] %s\n' "$((i+1))" "${items[$i]}" >&2; done
  printf 'Enter number: ' >&2
  local sel; read -r sel
  case "$sel" in (''|*[!0-9]*) return 1;; esac
  [ "$sel" -ge 1 ] && [ "$sel" -le "${#items[@]}" ] || return 1
  printf '%s\n' "${items[$((sel-1))]}"
}

resolve_pkg() { # $1=input -> print AUR pkg (stdout only)
  local input="$1" candidates=() c regex
  if is_github_url "$input"; then
    log_info "Input looks like a GitHub URL. Deriving candidates from README/title…"
    mapfile -t candidates < <(build_candidates_from_github "$input")
  else
    local b; b="$(normalize_kebab "$input")"
    candidates=("$b" "${b}-git" "${b}-bin" "${b}-appimage")
  fi

  [ "$FAST" = "1" ] && mapfile -t candidates < <(printf '%s\n' "${candidates[@]}" | prefer_fast_variant)

  # Exact AUR match check
  for c in "${candidates[@]}"; do
    if yay_exists_any "$c" && [ "$(yay_repo_of "$c")" = "aur" ]; then
      printf '%s\n' "$c"
      return 0
    fi
  done

  # Build strict regex from best candidate:
  # Prefer a dashed base WITHOUT suffix (-git|-bin|-appimage), taking the first
  # in candidates order (so README-derived names win).
  local dashed head
  dashed="$(
    printf '%s\n' "${candidates[@]}" \
      | grep -E '^[a-z0-9]+(-[a-z0-9]+)+$' \
      | grep -Ev '(-git|-bin|-appimage)$' \
      | head -n1
  )"

  if [ -n "$dashed" ]; then
    regex="^${dashed}(-git|-bin|-appimage)?$"
  else
    head="$(printf '%s' "${candidates[0]}")"; head="${head%%-*}"
    regex="^${head}([^-].*)?$"
  fi

  # search_term to feed into yay -Ss (no anchors), while regex stays anchored
  local search_term
  if [ -n "$dashed" ]; then
    search_term="$dashed"
  else
    search_term="$head"
  fi

  log_info "No exact AUR match. Expanding with name-strict AUR search: /$regex/"
  local -a hits=()
  mapfile -t hits < <(aur_search_name_strict_aur_only "$search_term" "$regex")

  if [ "${#hits[@]}" -eq 0 ]; then
    head="$(printf '%s' "${candidates[0]}")"; head="${head%%-*}"
    log_info "No matches with dashed term, trying with base: '$head'"
    mapfile -t hits < <(aur_search_name_strict_aur_only "$head" "^${head}([-].*)?$")
  fi

  [ "${#hits[@]}" -gt 0 ] || { log_warn "No AUR candidates matched by name."; return 1; }
  [ "${#hits[@]}" -eq 1 ] && { printf '%s\n' "${hits[0]}"; return 0; }

  log_info "Multiple AUR candidates after strict filtering."
  local chosen
  if chosen="$(printf '%s\n' "${hits[@]}" | select_from_list)"; then
    printf '%s\n' "$chosen"; return 0
  else
    return 1
  fi
}

# --- PKGBUILD verification helpers ---
ALLOWED_DOMAINS="${ALLOWED_DOMAINS:-github.com|codeload.github.com|objects.githubusercontent.com|gitlab.com}"

has_strong_sums() { grep -Eq '^[[:space:]]*(sha256sums|sha512sums)='; }
has_weak_or_skip() { grep -Eq '^[[:space:]]*(md5sums|sha1sums)=' || grep -Eq '(^|[[:space:]])SKIP([[:space:]]|")'; }

list_sources() {
  sed -n "s/^[[:space:]]*source[[:space:]]*=[[:space:]]*(\(.*\))/\1/p" \
    | tr ' ' '\n' | tr -d '"' "'" \
    | sed "s/[()']//g" | grep -E '^(https?|git|ftp)://|::https?://|::git://'
}

sources_have_only_https() { awk '!/^https:\/\// {bad=1} END{exit bad}'; }
sources_domains_allowed() { grep -Ev "$ALLOWED_DOMAINS" >/dev/null && return 1 || return 0; }

print_func_summaries() {
  awk '
    /^prepare\(\)/ {inp=1; print "---- prepare() ----"; next}
    /^build\(\)/   {inb=1; print "---- build() ----";   next}
    /^package\(\)/ {inpkg=1; print "---- package() ----";next}
    inp && /^\}/ {inp=0} inb && /^\}/ {inb=0} inpkg && /^\}/ {inpkg=0}
    inp||inb||inpkg { print }
  ' "$1" | sed 's/^[[:space:]]\{0,2\}//'
}

rewrite_sums_to_sha256() { # dir with PKGBUILD
  local dir="$1"
  (cd "$dir"
    makepkg --noconfirm --nodeps --noprepare --noextract -g >/dev/null 2>&1 || true
    local gen; gen="$(makepkg -g 2>/dev/null || true)"
    if ! printf '%s\n' "$gen" | grep -q '^sha256sums='; then
      log_warn "makepkg -g did not produce sha256sums; skipping rewrite."
      return 1
    fi
    awk -v repl="$(printf '%s' "$gen" | sed 's/[&/\]/\\&/g')" '
      BEGIN{printed=0}
      /^[[:space:]]*(md5sums|sha1sums|sha256sums|sha512sums)=/ {
        if (!printed) { print repl; printed=1 }
        next
      }
      { print }
    ' PKGBUILD > PKGBUILD.new && mv PKGBUILD.new PKGBUILD
  )
}

scan_red_flags() { # PKGBUILD path
  grep -Eni \
    -e 'curl[[:space:]]*\|[[:space:]]*sh' \
    -e 'wget[[:space:]]*\|[[:space:]]*sh' \
    -e 'eval[[:space:]]' \
    -e 'base64[[:space:]]*-d' \
    -e 'openssl[[:space:]]+enc' \
    -e '/dev/tcp' \
    -e 'rm[[:space:]]*-rf[[:space:]]+/' \
    -e 'useradd[[:space:]]' \
    -e 'systemctl[[:space:]]' \
    -e 'setcap[[:space:]]' \
    -e 'chmod[[:space:]]4[0-9]{3}' \
    -e 'python[[:space:]]+-c' \
    -e 'perl[[:space:]]+-e' \
    -e 'ruby[[:space:]]+-e' \
    -e 'node[[:space:]]+-e' \
    "$1" || true
}

verify_pkgbuild() { # $1=AUR pkg name
  local pkg="$1"
  local workdir; workdir="$(mktemp -d -t aurver-XXXXXX)"
  trap 'rm -rf "$workdir"' EXIT

  log_info "Cloning AUR: $pkg"
  git clone --depth=1 "https://aur.archlinux.org/${pkg}.git" "$workdir/$pkg" >/dev/null 2>&1 || die "Failed to clone AUR repo."

  [ -f "$workdir/$pkg/PKGBUILD" ] || die "PKGBUILD not found."
  local pkgb="$workdir/$pkg/PKGBUILD"

  log_info "Showing PKGBUILD function summaries (prepare/build/package)…"
  print_func_summaries "$pkgb" | sed 's/^/  /' >&2

  local sources
  sources="$(sed -n 'p' "$pkgb" | list_sources || true)"

  if [ -n "$sources" ]; then
    if ! printf '%s\n' "$sources" | sources_have_only_https; then
      [ "$STRICT" = "1" ] && die "HTTP or non-HTTPS sources are forbidden in STRICT."
      log_warn "Non-HTTPS sources detected (allowed in normal mode, but discouraged)."
    fi
    if ! printf '%s\n' "$sources" | grep -E "$ALLOWED_DOMAINS" >/dev/null; then
      [ "$STRICT" = "1" ] && die "Source domains not in whitelist."
      log_warn "Source domains outside whitelist (normal mode: allowed but warned)."
    fi
  fi

  if sed -n 'p' "$pkgb" | has_weak_or_skip; then
    if [ "$STRICT" = "1" ]; then
      die "Weak sums (md5/sha1) or SKIP detected in STRICT mode."
    else
      if [ "$FAST" = "1" ]; then
        log_warn "FAST=1: skipping downloads; cannot auto-upgrade sums."
      else
        log_info "Auto-upgrading checksums to sha256…"
        rewrite_sums_to_sha256 "$workdir/$pkg" || log_warn "Failed to rewrite sums; continuing."
      fi
    fi
  elif ! sed -n 'p' "$pkgb" | has_strong_sums; then
    if [ "$STRICT" = "1" ]; then
      die "No strong sums (sha256/sha512) declared."
    else
      if [ "$FAST" = "1" ]; then
        log_warn "FAST=1: skipping downloads; cannot add sha256sums."
      else
        log_info "No strong sums declared; attempting to generate sha256sums…"
        rewrite_sums_to_sha256 "$workdir/$pkg" || log_warn "Failed to add sha256sums."
      fi
    fi
  fi

  local flags; flags="$(scan_red_flags "$pkgb")"
  if [ -n "$flags" ]; then
    log_warn "Potential red flags found in PKGBUILD:"
    printf '%s\n' "$flags" | sed 's/^/  /' >&2
    [ "$STRICT" = "1" ] && die "Aborting due to red flags in STRICT."
  fi

  if [ "$FAST" = "1" ]; then
    log_info "FAST=1: Skipping makepkg --verifysource."
  else
    log_info "Running makepkg --verifysource (no build)…"
    if ! (cd "$workdir/$pkg" && makepkg --noconfirm --nodeps --verifysource); then
      [ "$STRICT" = "1" ] && die "makepkg --verifysource failed in STRICT mode."
      log_warn "makepkg --verifysource failed (normal mode: warn)."
    fi
  fi

  if [ "$VERIFY_ONLY" = "1" ]; then
    log_info "VERIFY_ONLY=1 -> Verification finished. Not installing."
    return 0
  fi

  log_info "Verification passed. Proceeding to install: $pkg"
  "$YAY_BIN" -S "$pkg"
}

install_or_verify() {
  local pkg="$1"
  if [ "$VERIFY_ONLY" = "1" ]; then
    log_info "VERIFY_ONLY=1 -> Showing metadata:"
    yay_query_any "$pkg" || true
  fi
  verify_pkgbuild "$pkg"
}

main() {
  local input=""
  while [ $# -gt 0 ]; do
    case "$1" in
      --verify-only) VERIFY_ONLY=1; shift;;
      --fast)        FAST=1; shift;;
      --strict)      STRICT=1; shift;;
      --)            shift; break;;
      -*)
        die "Unknown option: $1"
        ;;
      *)
        input="$1"; shift; break;;
    esac
  done
  [ -n "$input" ] || die "Usage: $0 [--verify-only] [--fast] [--strict] <aur_pkg | github_url>"

  local pkg
  pkg="$(resolve_pkg "$input")"  # logs go to stderr; stdout is only the pkg name
  [ -n "$pkg" ] || die "Unable to resolve an AUR package from input."
  log_info "Resolved package: $pkg"
  install_or_verify "$pkg"
}

main "$@"
#!/usr/bin/env bash
# aur_verify_then_yay.sh
# -------------------------------------------------------------
# Purpose:
#   Verify an AUR package *without building*. If clean, install with `yay -S`.
#   Normal mode: if PKGBUILD uses weak sums (sha1) or SKIP, auto-download sources,
#                compute sha256 and rewrite to sha256sums, then re-verify.
#   STRICT mode: enforce hard rules (see below), do NOT auto-fix; abort on violations.
#
# STRICT mode adds:
#   - PGP enforcement if .sig sources are present (must pass `makepkg --verifysource`).
#   - Forbid checksum weaknesses outright: sha1, SKIP, or no strong sums.
#   - Whitelist allowed source domains (default: github.com, codeload.github.com,
#     objects.githubusercontent.com, gitlab.com). Everything else is rejected.
#   - Expanded red-flag patterns (python -c, perl -e, ruby -e, node -e, exec with eval-like use).
#   - Prints a short summary of PKGBUILD functions (prepare/build/package) before install.
#
# NEW (discovery improvements):
#   - Plan A: accept match if PKGBUILD references GitHub repo in `source=()` OR in `url=`.
#   - Plan B: if no match by heuristics, query `yay -Ssq <repo>` to enumerate AUR candidates
#             and try each until a match is found.
#
# Workflow (both modes):
#   1) Input: AUR package name OR GitHub URL.
#   2) If GitHub URL, infer the AUR package by scanning candidates (+ Plan B).
#   3) Clone AUR repo (PKGBUILD only), no compilation.
#   4) Static checks:
#      - Fatal: http:// sources, dangerous patterns (curl|wget piping to shell, eval,
#        base64 -d, openssl enc, writes to /etc, systemctl, useradd, setcap,
#        chmod 4xxx, /dev/tcp, rm -rf /, etc.). (Expanded in STRICT)
#      - Normal: sha1/SKIP/no-strong → auto-upgrade to sha256 and re-verify.
#      - STRICT: sha1/SKIP/no-strong → abort.
#      - STRICT: sources must match whitelist of allowed domains.
#      - STRICT: if *.sig sources exist, PGP verification must pass.
#   5) `makepkg --verifysource` (integrity only, no build).
#   6) If all good, install via `yay -S <pkg>`.
#   7) Always cleanup temp files at exit.
#
# Usage:
#   sh ./aur_verify_then_yay.sh [--verify-only] [--fast] <aur_pkg | github_url>
#   sh ./aur_verify_then_yay.sh appname-from-aur
#   sh ./aur_verify_then_yay.sh "https://github.com/<owner>/<repo>.git"
#
# Env:
#   YAY_BIN=</path/to/yay>  # default: "yay"
#   STRICT=1                # enable strict mode (paranoia-friendly)
#   VERIFY_ONLY=1           # do all checks but DO NOT install
#   FAST=1                  # metadata-only checks (skip source downloads)
#
# Note:
#   Auto-converting to sha256 (normal mode) validates integrity of files downloaded now.
#   It does NOT prove upstream authenticity unless verified with trusted signatures/hashes.

set -euo pipefail

die(){ echo "[ERROR] $*" >&2; exit 1; }
note(){ echo "[INFO] $*"; }
warn(){ echo "[WARN] $*" >&2; }

need_cmd(){ command -v "$1" >/dev/null 2>&1 || die "Missing required tool: $1"; }
need_cmd git
need_cmd curl
need_cmd makepkg
YAY_BIN="${YAY_BIN:-yay}"
need_cmd "$YAY_BIN"

STRICT="${STRICT:-0}"
VERIFY_ONLY="${VERIFY_ONLY:-0}"
FAST="${FAST:-0}"

print_usage(){
  cat <<USAGE
Usage: $0 [--verify-only] [--fast] <AUR_PACKAGE_NAME | GITHUB_URL>

Options:
  --verify-only   Run checks and exit without installing.
  --fast          Metadata-only checks (skip makepkg --verifysource downloads).
                  In STRICT mode this weakens verification; use with caution.
  -h, --help      Show this help and exit.
USAGE
}

# Parse flags (optional), then the single positional INPUT
ARGS=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --verify-only) VERIFY_ONLY=1; shift ;;
    --fast)        FAST=1; shift ;;
    -h|--help)     print_usage; exit 0 ;;
    --)            shift; break ;;
    -*)            die "Unknown option: $1" ;;
    *)             ARGS+=("$1"); shift ;;
  esac
done
[[ ${#ARGS[@]} -eq 1 ]] || { print_usage; exit 1; }
set -- "${ARGS[@]}"

[[ $# -eq 1 ]] || die "Usage: $0 <AUR_PACKAGE_NAME | GITHUB_URL>"
INPUT="$1"

WORK="$(mktemp -d -t aur-verify-XXXXXX)"
cleanup(){ rm -rf "$WORK"; }
trap cleanup EXIT
cd "$WORK"

is_github_url=0
if [[ "$INPUT" =~ ^https?://(www\.)?github\.com/ ]]; then
  is_github_url=1
fi

# --- yay metadata helpers (used by --fast path) ---
yay_field() { # $1=pkg $2=Field Name
  "$YAY_BIN" -Si "$1" 2>/dev/null | sed -n "s/^$2[[:space:]]*:[[:space:]]*//p" | head -n1 || true
}
yay_repo_of()       { yay_field "$1" "Repository"; }
yay_upstream_of()   { local u; u=$(yay_field "$1" "Upstream URL"); [[ -n "$u" ]] && echo "$u" || yay_field "$1" "URL"; }
# More robust existence check across yay versions: rely on -Si exit status
yay_exists()        { "$YAY_BIN" -Si "$1" >/dev/null 2>&1; }
prefer_quick_pkg() { # pick fastest-to-install candidate for base name
  local base="$1" cand
  # 1) exact package in official repos
  if yay_exists "$base"; then
    local repo; repo=$(yay_repo_of "$base")
    if [[ -n "$repo" && "$repo" != "aur" ]]; then echo "$base"; return 0; fi
  fi
  # 2) preferred prebuilt flavors in AUR (still makepkg but quick)
  for cand in "${base}-bin" "${base}-appimage" "${base}-prebuilt"; do
    if yay_exists "$cand"; then echo "$cand"; return 0; fi
  done
  # 3) fallback to base if available
  if yay_exists "$base"; then echo "$base"; return 0; fi
  return 1
}

metadata_matches_owner_repo() { # $1=pkg $2=owner $3=repo
  local url; url=$(yay_upstream_of "$1")
  [[ -n "$url" ]] && echo "$url" | grep -Eqi "github\.com/${2}/${3}(/|$)"
}

normalize_sources() {
  awk '
    $1 ~ /^source[[:space:]]*=/ {
      sub(/^[^=]*=/, "", $0);
      gsub(/[()"]/, "", $0);
      print
    }' PKGBUILD | tr '\n' ' ' | sed -E 's/[[:space:]]+/ /g'
}
get_sources_tokens() {
  local line; line="$(normalize_sources || true)"
  if [[ -n "$line" ]]; then
    printf "%s\n" "$line" | tr ' ' '\n' | sed '/^$/d'
  fi
}
pkgbuild_matches_owner_repo() {
  local owner="$1" repo="$2"
  grep -Eqi "github\.com/${owner}/${repo}(/|$)" PKGBUILD && return 0
  grep -Eqi '^url=.*github\.com/'"$owner/$repo" PKGBUILD && return 0
  return 1
}

PKGNAME=""

if [[ "$FAST" -eq 1 ]]; then
  # Metadata-only discovery and verification
  if [[ $is_github_url -eq 1 ]]; then
    note "FAST: resolving package by metadata from GitHub URL..."
    if [[ "$INPUT" =~ github\.com/([^/]+)/([^/]+)/? ]]; then
      OWNER="${BASH_REMATCH[1]}"; REPO="${BASH_REMATCH[2]%%.git}"
    else
      die "Could not extract owner/repo from URL: $INPUT"
    fi
    mapfile -t yay_hits < <("$YAY_BIN" -Ssq "$REPO" || true)
    # Choose by upstream match, preferring repo packages then -bin/appimage
    best="" best_score=0
    for cand in "${yay_hits[@]}" "${REPO}" "${REPO}-bin" "${REPO}-appimage"; do
      [[ -z "$cand" ]] && continue
      [[ "$cand" == */* ]] && continue
      yay_exists "$cand" || continue
      if metadata_matches_owner_repo "$cand" "$OWNER" "$REPO"; then
        repo=$(yay_repo_of "$cand")
        score=1
        [[ "$repo" != "aur" ]] && score=3
        [[ "$cand" =~ -(bin|appimage)$ ]] && (( score++ ))
        if (( score > best_score )); then best="$cand"; best_score=$score; fi
      fi
    done
    [[ -n "$best" ]] || die "Could not find a package in yay matching ${OWNER}/${REPO}."
    PKGNAME="$best"
    # Origin check info
    note "Chosen package: $PKGNAME (repo=$(yay_repo_of "$PKGNAME"), upstream=$(yay_upstream_of "$PKGNAME"))"
  else
    # Input is a package name: optionally switch to a faster flavor
    base="$INPUT"
    PKGNAME=$(prefer_quick_pkg "$base" || true)
    [[ -n "$PKGNAME" ]] || die "Package '$base' not found via yay."
    note "FAST: selected '$PKGNAME' for quick install (repo=$(yay_repo_of "$PKGNAME"))."
  fi
else
  # Full path with PKGBUILD clone and static checks
  if [[ $is_github_url -eq 1 ]]; then
    note "Input looks like a GitHub URL. Attempting to infer AUR package..."
    OWNER=""; REPO=""
    if [[ "$INPUT" =~ github\.com/([^/]+)/([^/]+)/? ]]; then
      OWNER="${BASH_REMATCH[1]}"; REPO="${BASH_REMATCH[2]%%.git}"
    else
      die "Could not extract owner/repo from URL: $INPUT"
    fi

    CANDS=("$REPO" "${REPO}-bin" "${REPO}-git" "${REPO}-appimage" "${REPO}-appimage-git")
    found=0
    for cand in "${CANDS[@]}"; do
      note "Trying AUR git clone (heuristic): $cand"
      REPO_DIR="aur-$cand"
      if git clone --depth=1 "https://aur.archlinux.org/${cand}.git" "$REPO_DIR" 2>/dev/null; then
        if [[ -d "$REPO_DIR" && -f "$REPO_DIR/PKGBUILD" ]]; then
          pushd "$REPO_DIR" >/dev/null
          if pkgbuild_matches_owner_repo "$OWNER" "$REPO"; then
            PKGNAME="$cand"; found=1; popd >/dev/null; break
          fi
          popd >/dev/null
        else
          warn "Clone succeeded but PKGBUILD missing in $REPO_DIR; skipping."
        fi
      else
        warn "Clone failed for $cand; skipping."
      fi
    done

    if [[ $found -eq 0 ]]; then
      note "No match by heuristic. Expanding search via 'yay -Ssq $REPO'..."
      mapfile -t yay_hits < <("$YAY_BIN" -Ssq "$REPO" || true)
      for cand in "${yay_hits[@]}"; do
        [[ "$cand" == */* ]] && continue  # skip repo-qualified like extra/foo
        note "Trying AUR git clone (expanded): $cand"
        REPO_DIR="aur-$cand"
        if git clone --depth=1 "https://aur.archlinux.org/${cand}.git" "$REPO_DIR" 2>/dev/null; then
          if [[ -d "$REPO_DIR" && -f "$REPO_DIR/PKGBUILD" ]]; then
            pushd "$REPO_DIR" >/dev/null
            if pkgbuild_matches_owner_repo "$OWNER" "$REPO"; then
              PKGNAME="$cand"; found=1; popd >/dev/null; break
            fi
            popd >/dev/null
          else
            warn "Clone succeeded but PKGBUILD missing in $REPO_DIR; skipping."
          fi
        else
          warn "Clone failed for $cand; skipping."
        fi
      done
    fi

    [[ -n "$PKGNAME" ]] || die "Could not find an AUR package referencing ${OWNER}/${REPO}. Try passing the AUR package name directly (e.g., one from 'yay -Ss ${REPO}')."
    cd "aur-$PKGNAME"

  else
    PKGNAME="$INPUT"
    note "Cloning AUR package: $PKGNAME"
    REPO_DIR="aur-$PKGNAME"
    git clone --depth=1 "https://aur.archlinux.org/${PKGNAME}.git" "$REPO_DIR" \
      || die "AUR clone failed for $PKGNAME (package may not exist)."
    [[ -f "$REPO_DIR/PKGBUILD" ]] || die "PKGBUILD not found in the AUR repo."
    cd "$REPO_DIR"
  fi

  [[ -f PKGBUILD ]] || die "PKGBUILD not found after entering repo."
fi

# --- STATIC CHECKS ---
if [[ "$FAST" -eq 0 ]]; then
  if grep -E '^\s*source=.*http://' PKGBUILD >/dev/null; then
    die "Insecure source URL (http://) detected in PKGBUILD."
  fi

BASE_RED_FLAGS='(curl|wget).*(sh|bash)|/dev/tcp|eval|base64[[:space:]]+-d|openssl[[:space:]]+enc|rm[[:space:]]+-rf[[:space:]]+/|chmod[[:space:]]+4[0-9]{3}|useradd|passwd|systemctl|chown[[:space:]]+root|setcap|>/etc/|[^_]PKGDIR|[^_]pkgdir[[:space:]]*=[[:space:]]*/etc'
STRICT_EXTRA_FLAGS='python[[:space:]]+-c|perl[[:space:]]+-e|ruby[[:space:]]+-e|node[[:space:]]+-e|exec[[:space:]]*\(|\$\(|`[^`]+`'
ALL_FLAGS="$BASE_RED_FLAGS"
[[ "$STRICT" -eq 1 ]] && ALL_FLAGS="$BASE_RED_FLAGS|$STRICT_EXTRA_FLAGS"

  if grep -nE "$ALL_FLAGS" PKGBUILD >/dev/null 2>&1; then
    echo "=== Suspicious lines ==="
    grep -nE "$ALL_FLAGS" PKGBUILD || true
    die "Red flags detected in PKGBUILD. Aborting."
  fi

HAS_SHA1=0; HAS_STRONG=0; HAS_SKIP=0
  grep -E '^\s*sha1sums='            PKGBUILD >/dev/null && HAS_SHA1=1
  grep -E '^\s*(sha256sums|b2sums)=' PKGBUILD >/dev/null && HAS_STRONG=1
  grep -E "^\s*(sha256sums|b2sums)='?\(.*SKIP" PKGBUILD >/dev/null && HAS_SKIP=1

if [[ "$FAST" -eq 0 && "$STRICT" -eq 1 ]]; then
  [[ $HAS_SHA1 -eq 1 ]] && die "STRICT: sha1sums detected."
  [[ $HAS_SKIP -eq 1 ]] && die "STRICT: SKIP found in checksum array."
  [[ $HAS_STRONG -eq 0 ]] && die "STRICT: no strong checksum array (sha256/b2)."
else
  [[ $HAS_SHA1 -eq 1 ]] && warn "Weak checksum (sha1sums); will auto-upgrade to sha256 after download."
  [[ $HAS_SKIP -eq 1 ]] && warn "SKIP in checksums; will compute sha256 for downloadable sources."
  [[ $HAS_STRONG -eq 0 ]] && warn "No strong checksum array; will generate sha256sums after download."
fi

fi

if [[ "$STRICT" -eq 1 ]]; then
  ALLOWED_DOMAINS='(github\.com|codeload\.github\.com|objects\.githubusercontent\.com|gitlab\.com)'
  mapfile -t TOKS < <(get_sources_tokens || true)
  for tok in "${TOKS[@]:-}"; do
    url="${tok##*::}"
    if [[ "$url" =~ ^git\+ ]] || [[ "$url" =~ \.git($|#) ]]; then
      continue
    fi
    if [[ "$url" =~ ^https:// ]] && ! [[ "$url" =~ $ALLOWED_DOMAINS ]]; then
      die "STRICT: source domain not allowed -> $url"
    fi
  done
fi

if [[ "$FAST" -eq 0 ]]; then
  note "Running initial 'makepkg --verifysource' (no build)..."
  if ! makepkg --verifysource; then
    die "Source verification failed (as-is)."
  fi
else
  note "FAST: metadata-only verification vía 'yay -Si'."
  if [[ "$STRICT" -eq 1 ]]; then
    # Basic domain allowlist on upstream URL if present
    upstream=$(yay_upstream_of "$PKGNAME" || true)
    if [[ -n "$upstream" ]]; then
      ALLOWED_DOMAINS='(github\.com|codeload\.github\.com|objects\.githubusercontent\.com|gitlab\.com)'
      if [[ "$upstream" =~ ^https:// ]] && ! [[ "$upstream" =~ $ALLOWED_DOMAINS ]]; then
        die "STRICT: upstream domain not allowed -> $upstream"
      fi
    else
      warn "STRICT: package has no upstream URL in metadata."
    fi
  fi
fi

if [[ "$STRICT" -eq 1 ]]; then
  if grep -E 'source=.*\.sig([")[:space:]]|$)' PKGBUILD >/dev/null; then
    note "STRICT: PGP signature(s) present and verified."
  else
    warn "STRICT: no .sig files declared; upstream authenticity not cryptographically verified."
  fi
fi

if [[ "$STRICT" -eq 0 && "$FAST" -eq 0 ]]; then
  needs_upgrade=0
  [[ $HAS_SHA1 -eq 1 || $HAS_SKIP -eq 1 || $HAS_STRONG -eq 0 ]] && needs_upgrade=1
  if [[ $needs_upgrade -eq 1 ]]; then
    note "Computing sha256 for downloadable sources and rewriting checksums..."
    SRC_LINE="$(normalize_sources || true)"
    if [[ -n "${SRC_LINE}" ]]; then
      mapfile -t SRC_TOKENS < <(printf "%s" "$SRC_LINE" | tr ' ' '\n' | sed '/^$/d')
      SHA256_ARRAY=()
      for tok in "${SRC_TOKENS[@]}"; do
        url="${tok##*::}"
        if [[ "$url" =~ ^git\+ ]] || [[ "$url" =~ \.git($|#) ]]; then
          SHA256_ARRAY+=("SKIP"); continue
        fi
        base="$(basename "${url%%\?*}")"
        fpath=""
        if [[ -f "$base" ]]; then fpath="$base"
        elif [[ -n "${SRCDEST:-}" && -f "${SRCDEST%/}/$base" ]]; then fpath="${SRCDEST%/}/$base"
        elif [[ -n "${SRCDEST:-}" && -f "$SRCDEST/$base" ]]; then fpath="$SRCDEST/$base"
        fi
        if [[ -n "$fpath" ]]; then
          sha=$(sha256sum "$fpath" | awk '{print $1}')
          SHA256_ARRAY+=("$sha"); note "sha256($base)=$sha"
        else
          SHA256_ARRAY+=("SKIP"); warn "Could not locate downloaded file for '$base'; leaving SKIP."
        fi
      done
      sed -i -E '/^[a-z0-9_]*sums=\(/d' PKGBUILD
      { printf "sha256sums=("; for h in "${SHA256_ARRAY[@]}"; do printf "'%s' " "$h"; done; printf ")\n"; } >> PKGBUILD
      note "Re-running 'makepkg --verifysource' with regenerated sha256s..."
      if ! makepkg --verifysource; then
        die "sha256 verification failed after regeneration. Aborting."
      fi
    else
      warn "No source=() array found; skipping checksum regeneration."
    fi
  fi
fi

if [[ "$STRICT" -eq 1 && "$FAST" -eq 0 ]]; then
  note "STRICT: PKGBUILD function summary (first lines of each):"
  awk '
    /^[[:space:]]*(prepare|build|check|package)[[:space:]]*\(\)[[:space:]]*\{/ {fn=$1; print "==> " fn; show=1; next}
    show==1 { if (match($0,/^\}/)) {show=0; print ""} else {print "    " $0} }
  ' PKGBUILD || true
fi

if [[ "$VERIFY_ONLY" -eq 1 ]]; then
  note "Verification complete. Skipping installation (--verify-only)."
  exit 0
fi

if [[ "$FAST" -eq 1 ]]; then
  # Avoid heavy builds when possible
  repo=$(yay_repo_of "$PKGNAME")
  if [[ "$repo" == "aur" && ! "$PKGNAME" =~ -(bin|appimage|prebuilt)$ ]]; then
    # Try to switch automatically to a *-bin flavor
    alt=$(prefer_quick_pkg "$PKGNAME" || true)
    if [[ -n "$alt" && "$alt" != "$PKGNAME" ]]; then
      note "FAST: switching to quick variant '$alt' for installation."
      PKGNAME="$alt"
    else
      die "FAST: '${PKGNAME}' would require a full AUR build. Abort to avoid compilation."
    fi
  fi
fi

note "All checks passed. Installing via yay: $PKGNAME ..."
"$YAY_BIN" -S --noconfirm "$PKGNAME" || die "yay failed to install $PKGNAME"
note "Done. '$PKGNAME' installed via yay."
